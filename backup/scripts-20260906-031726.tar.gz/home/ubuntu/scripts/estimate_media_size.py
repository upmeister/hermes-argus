#!/usr/bin/env python3
"""
Оценка размера медиа-хранилища для треда 2ch.

Скачивает все посты треда, анализирует вложения (HEAD-запросами),
выдаёт сводку: сколько места займут все медиа за N дней при текущей
частоте постинга.

Использование:
    python3 estimate_media_size.py [--thread URL] [--days 7]
"""

import argparse
import asyncio
import sys
import time
from collections import defaultdict
from datetime import datetime

import aiohttp

# ── Конфигурация ──────────────────────────────────────────────

DOMAINS = ["https://2ch.su", "https://2ch.org"]  # .hk недоступен
MEDIA_BASE = "https://2ch.su"  # для HEAD-запросов к файлам

# Типы файлов из 2ch API (FileType enum)
FILETYPE_NAMES = {
    0: "none",
    1: "jpg",
    2: "png",
    3: "apng",
    4: "gif",
    5: "bmp",
    6: "webm",
    7: "mp3",
    8: "ogg",
    10: "mp4",
    100: "sticker",
}

# Категории для группировки
FILETYPE_CATEGORY = {
    0: "other",
    1: "image", 2: "image", 3: "image", 4: "image", 5: "image",
    6: "video",
    7: "audio", 8: "audio",
    10: "video",
    100: "sticker",
}

RATE_LIMIT = 1.0  # секунд между HEAD-запросами (щадящий режим)


# ── API-клиент (минимальный) ──────────────────────────────────

async def fetch_posts(
    session: aiohttp.ClientSession,
    board: str,
    thread: int,
) -> list[dict]:
    """Получить все посты треда через /after endpoint с fallback по доменам."""
    for domain in DOMAINS:
        url = f"{domain}/api/mobile/v2/after/{board}/{thread}/{thread}"
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=20)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    error = data.get("error")
                    if error and error.get("code") != 0 and error.get("code") is not None:
                        print(f"  ⚠️ API error {error.get('code')}: {error.get('message')}")
                        return []
                    posts = data.get("posts", [])
                    print(f"  ✅ {domain} — получено {len(posts)} постов")
                    return posts
                else:
                    print(f"  ⚠️ {domain} → HTTP {resp.status}")
        except asyncio.TimeoutError:
            print(f"  ⚠️ {domain} → таймаут")
        except Exception as e:
            print(f"  ⚠️ {domain} → {e}")
    return []


async def head_file(
    session: aiohttp.ClientSession,
    file_info: dict,
    semaphore: asyncio.Semaphore,
) -> dict:
    """HEAD-запрос к файлу для определения размера."""
    path = file_info.get("path", "")
    if not path:
        return {**file_info, "real_size_bytes": 0, "accessible": False, "error": "no path"}

    # path обычно вида "/hry/src/1168672/17533694325670.mp4"
    url = f"https://2ch.su{path}" if path.startswith("/") else path

    async with semaphore:
        try:
            async with session.head(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    size = int(resp.headers.get("Content-Length", 0))
                    return {
                        **file_info,
                        "real_size_bytes": size,
                        "accessible": True,
                        "error": None,
                    }
                else:
                    return {
                        **file_info,
                        "real_size_bytes": 0,
                        "accessible": False,
                        "error": f"HTTP {resp.status}",
                    }
        except asyncio.TimeoutError:
            return {**file_info, "real_size_bytes": 0, "accessible": False, "error": "timeout"}
        except Exception as e:
            return {**file_info, "real_size_bytes": 0, "accessible": False, "error": str(e)[:80]}


# ── Анализ ─────────────────────────────────────────────────────

def analyze(posts: list[dict], checked_files: list[dict], days: int):
    """Выдать сводку."""
    total_posts = len(posts)
    posts_with_files = sum(1 for p in posts if p.get("files"))
    total_files_api = sum(len(p.get("files") or []) for p in posts)

    # Временной диапазон постов
    timestamps = [p.get("timestamp", 0) for p in posts if p.get("timestamp")]
    if timestamps:
        oldest = min(timestamps)
        newest = max(timestamps)
        span_seconds = newest - oldest
        span_days = max(span_seconds / 86400, 0.01)
        posts_per_day = total_posts / span_days
    else:
        span_days = 1
        posts_per_day = total_posts

    # Категоризация файлов
    by_category = defaultdict(lambda: {"count": 0, "size_bytes": 0, "accessible": 0, "inaccessible": 0})
    by_type = defaultdict(lambda: {"count": 0, "size_bytes": 0})

    total_real_size = 0
    accessible_count = 0
    inaccessible_count = 0

    for f in checked_files:
        cat = FILETYPE_CATEGORY.get(f.get("type", 0), "other")
        type_name = FILETYPE_NAMES.get(f.get("type", 0), f"type_{f.get('type', 0)}")
        size = f.get("real_size_bytes", 0)

        by_category[cat]["count"] += 1
        by_category[cat]["size_bytes"] += size
        by_type[type_name]["count"] += 1
        by_type[type_name]["size_bytes"] += size

        if f.get("accessible"):
            by_category[cat]["accessible"] += 1
            accessible_count += 1
            total_real_size += size
        else:
            by_category[cat]["inaccessible"] += 1
            inaccessible_count += 1

    # Оценка API-размера (то что 2ch сообщает)
    total_api_size_kb = sum(
        f.get("size", 0) for p in posts for f in (p.get("files") or [])
    )

    # Экстраполяция на N дней
    files_per_day = total_files_api / span_days if span_days > 0 else total_files_api
    real_size_per_day = total_real_size / span_days if span_days > 0 else total_real_size
    projected_size = real_size_per_day * days

    # Вывод
    print()
    print("=" * 70)
    print("📊 ОЦЕНКА МЕДИА-ХРАНИЛИЩА")
    print("=" * 70)
    print()
    print("┌─ ОБЩАЯ СТАТИСТИКА")
    print(f"│  Постов в треде:              {total_posts}")
    print(f"│  Из них с вложениями:         {posts_with_files} ({posts_with_files*100//max(total_posts,1)}%)")
    print(f"│  Всего вложений (по API):     {total_files_api}")
    print(f"│  Уникальных авторов:          {posts[0].get('__unique_posters', '?') if posts else '?'}")
    print(f"│")
    print(f"│  Диапазон дат:                {span_days:.1f} дней")
    print(f"│  Постов в день (среднее):     {posts_per_day:.1f}")
    print(f"│  Вложений в день (среднее):   {files_per_day:.1f}")
    print()

    print("┌─ РАЗМЕР ВЛОЖЕНИЙ (ПО API)")
    print(f"│  Общий (из API):              {total_api_size_kb/1024:.1f} MB ({total_api_size_kb:,} KB)")
    print(f"│  Средний файл (API):          {total_api_size_kb/max(total_files_api,1):.0f} KB")
    print()

    print("┌─ РЕАЛЬНЫЙ РАЗМЕР (HEAD-запросы)")
    print(f"│  Проверено файлов:            {len(checked_files)}")
    print(f"│  Доступно:                    {accessible_count}")
    print(f"│  Недоступно:                  {inaccessible_count}")
    if accessible_count > 0:
        print(f"│  Общий реальный размер:       {total_real_size/1024/1024:.1f} MB ({total_real_size:,} bytes)")
        print(f"│  Средний файл (реальный):     {total_real_size/max(accessible_count,1)/1024:.0f} KB")
    print()

    print("┌─ ПО ТИПАМ ФАЙЛОВ")
    print(f"│  {'Тип':<12} {'Файлов':>7} {'Доступно':>9} {'Реальный размер':>16} {'% от общего':>11}")
    print(f"│  {'─'*12} {'─'*7} {'─'*9} {'─'*16} {'─'*11}")
    for cat in ["image", "video", "audio", "sticker", "other"]:
        if cat in by_category:
            c = by_category[cat]
            pct = (c["size_bytes"] / max(total_real_size, 1)) * 100
            print(f"│  {cat:<12} {c['count']:>7} {c['accessible']:>9} {c['size_bytes']/1024/1024:>15.1f} MB {pct:>10.1f}%")
    print()

    print("┌─ ПО ФОРМАТАМ")
    print(f"│  {'Формат':<12} {'Файлов':>7} {'Размер':>15}")
    print(f"│  {'─'*12} {'─'*7} {'─'*15}")
    for tname in sorted(by_type.keys()):
        t = by_type[tname]
        print(f"│  {tname:<12} {t['count']:>7} {t['size_bytes']/1024/1024:>14.1f} MB")
    if inaccessible_count > 0:
        print(f"│  {'(недоступно)':<12} {inaccessible_count:>7}")
    print()

    print("┌─ ПРОГНОЗ НА ПЕРИОД")
    print(f"│  Дней хранения:               {days}")
    print(f"│  Прогноз размера:             {projected_size/1024/1024:.1f} MB")
    print(f"│  С запасом 30%:               {projected_size*1.3/1024/1024:.1f} MB")
    
    # Для нескольких тредов
    for n_threads in [2, 5, 10]:
        multi = projected_size * n_threads / 1024 / 1024
        print(f"│  {n_threads} тредов (×{n_threads}):            {multi:.1f} MB")
    print()

    # Вывод: хватит ли 5 GB
    print("┌─ ВЫВОД")
    if projected_size / 1024**3 < 5:
        print(f"│  ✅ 5 GB хватит с запасом ({projected_size/1024**3:.2f} GB из 5 GB)")
    else:
        print(f"│  ❌ 5 GB НЕ хватит ({projected_size/1024**3:.2f} GB > 5 GB)")
        needed = projected_size / 1024**3 * 1.3
        print(f"│  Рекомендуемый лимит: {needed:.1f} GB")
    print()
    print("=" * 70)


# ── Точка входа ────────────────────────────────────────────────

async def main():
    parser = argparse.ArgumentParser(description="Оценка размера медиа-хранилища 2ch")
    parser.add_argument(
        "--thread", default="https://2ch.su/hry/res/822173.html",
        help="URL треда (по умолчанию: тред Галковского)"
    )
    parser.add_argument("--days", type=int, default=7, help="Горизонт прогноза в днях")
    parser.add_argument("--skip-head", action="store_true", help="Пропустить HEAD-запросы (только API-статистика)")
    parser.add_argument("--sample", type=int, default=0, help="Проверить только N случайных файлов (0 = все)")
    args = parser.parse_args()

    # Парсим URL
    import re
    m = re.search(r"2ch\.\w+/(\w+)/(?:res|arch)/(\d+)", args.thread)
    if not m:
        print(f"❌ Не удалось распарсить URL: {args.thread}")
        sys.exit(1)
    board, thread = m.group(1), int(m.group(2))

    print(f"🔍 Анализ треда /{board}/{thread}")
    print(f"   Доменов для fallback: {DOMAINS}")
    print()

    timeout = aiohttp.ClientTimeout(total=30)
    connector = aiohttp.TCPConnector(limit=5)
    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        # 1. Получаем все посты
        print("⏳ Загрузка постов...")
        posts = await fetch_posts(session, board, thread)
        if not posts:
            print("❌ Не удалось получить посты.")
            return

        # Сохраняем unique_posters (API возвращает его на верхнем уровне)
        # Берём из первого ответа — но мы уже спарсили, нужно иначе...
        # unique_posters сохраняется из первого успешного ответа
        # Но в нашей функции fetch_posts мы его теряем. Исправим:
        # Пока пропустим, это не критично для размера.

        # 2. Собираем все файлы
        all_files = []
        for p in posts:
            files = p.get("files") or []
            for f in files:
                all_files.append({
                    **f,
                    "post_num": p.get("num"),
                    "post_date": p.get("date"),
                })

        print(f"   Найдено вложений: {len(all_files)}")

        if not all_files:
            print("   В треде нет вложений — нечего оценивать.")
            # Всё равно покажем базовую статистику
            analyze(posts, [], args.days)
            return

        # 3. HEAD-запросы для реального размера
        if args.skip_head:
            print("   ⏭️  HEAD-запросы пропущены.")
            analyze(posts, [], args.days)
            return

        sample = args.sample
        files_to_check = all_files
        if sample and sample < len(all_files):
            import random
            files_to_check = random.sample(all_files, sample)
            print(f"   Проверяем {sample} из {len(all_files)} файлов (случайная выборка)...")
        else:
            print(f"   Проверяем все {len(all_files)} файлов...")
            print(f"   (Это может занять до {len(all_files) * RATE_LIMIT:.0f} секунд)")

        semaphore = asyncio.Semaphore(3)  # макс 3 одновременных HEAD-запроса
        t0 = time.monotonic()
        checked = []
        done = 0

        # Группируем по 10 для вывода прогресса
        for i in range(0, len(files_to_check), 10):
            batch = files_to_check[i:i+10]
            tasks = [head_file(session, f, semaphore) for f in batch]
            results = await asyncio.gather(*tasks)
            checked.extend(results)
            done += len(batch)
            elapsed = time.monotonic() - t0
            rate = done / elapsed if elapsed > 0 else 0
            print(f"   Прогресс: {done}/{len(files_to_check)} ({rate:.1f} файлов/сек)  ", end="\r")
            await asyncio.sleep(RATE_LIMIT)  # щадящий режим

        elapsed = time.monotonic() - t0
        print(f"\n   ✅ Готово за {elapsed:.1f} сек")

        # 4. Анализ
        analyze(posts, checked, args.days)


if __name__ == "__main__":
    asyncio.run(main())
