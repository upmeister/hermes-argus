#!/bin/bash
# check-integrations.sh — тонкая обёртка над единым каноном (2026-08-20).
#
# Консолидация: логика — в ~/.hermes/scripts/health-check-integrations.sh (режим --quick).
# Эта обёртка сохраняет вызовы из:
#   * hermes-watchdog.sh (L1, каждые 5 мин) — парсит stdout (строки "Label: msg" + заголовок)
#   * crontab hourly (15 * * * *)
# Формат вывода/exit-коды идентичны legacy-версии → совместимость без правки вызовов.
# Legacy-версия сохранена в check-integrations.sh.legacy-2026-08-20.
exec bash /home/ubuntu/.hermes/scripts/health-check-integrations.sh --quick
