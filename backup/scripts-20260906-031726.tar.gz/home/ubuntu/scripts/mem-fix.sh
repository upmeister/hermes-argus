#!/bin/bash
# ============================================================================
# mem-fix.sh — экстренная помощь при OOM/своп-трешинге на 2GB VPS.
#
# КОГДА: сервер не отвечает по SSH/Tailscale, dashboard/gateway мертвы,
#        load >10, swap забит — доступна только консоль хостера (VNC/серийная).
#
# Безопасен по умолчанию: БЕЗ аргументов — только диагностика (ничего не меняет).
# Действия — только с явными флагами:
#   --kill-workers   pkill -9 воркеров hermes (канбан-воркеры, hermes -p ...)
#   --stop-gateway    systemctl --user stop hermes-gateway (освобождает ~300MB+)
#   --kill-all        pkill -9 всех процессов hermes (крайний случай, полный stop)
#
# ПОСЛЕ любого действия: вывод `free -h` для контроля.
# ============================================================================
set -uo pipefail

log() { echo "[$(date '+%H:%M:%S')] $*"; }

echo "════════ mem-fix $(date '+%F %T') ════════"
free -h
echo "── Load ──"
uptime | grep -o 'load average.*'
echo "── Swap-активность (pswpin/pswpout, страниц/сек) ──"
awk '/pswpin|pswpout/ {print $1": "$2}' /proc/vmstat
echo "── Топ-8 процессов по RSS ──"
ps aux --sort=-rss | awk 'NR>1 && NR<=9 {printf "%-7s %5s%% %7.0fMB  %s\n", $2, $4, $6/1024, substr($0, index($0,$11), 90)}'
echo "── Процессы hermes ──"
pgrep -af "hermes" | head -15 || echo "  (нет)"

case "${1:-}" in
  --kill-workers)
    log "Killing kanban/hermes workers..."
    pkill -9 -f "hermes.* -p " && log "OK: workers killed" || log "workers not found"
    ;;
  --stop-gateway)
    log "Stopping hermes-gateway..."
    systemctl --user stop hermes-gateway 2>/dev/null || sudo -u covhnw XDG_RUNTIME_DIR=/run/user/1000 systemctl --user stop hermes-gateway 2>/dev/null
    log "done (systemd Restart=always поднимет при освобождении памяти — при необходимости: systemctl --user start hermes-gateway)"
    ;;
  --kill-all)
    log "Killing ALL hermes processes..."
    pkill -9 -f "hermes" && log "OK" || log "none found"
    ;;
  "") log "Диагностика только. Для действий: --kill-workers | --stop-gateway | --kill-all" ;;
  *) log "Неизвестный флаг: $1 (--kill-workers | --stop-gateway | --kill-all)" ;;
esac

echo "── После: ──"
free -h | head -2
