#!/bin/bash
# Push Obsidian vault to GitHub
set -a; source "$HOME/.hermes/.env"; set +a

cd "$HOME/obsidian-vault" || exit 0
git pull --rebase --autostash --quiet 2>/dev/null || true

# Mirror infra-changelog so humans can read it in Obsidian
mkdir -p logs
cp "$HOME/.hermes/logs/infra-changelog.md" logs/infra-changelog.md

git add -A
if git diff --cached --quiet; then
    exit 0
fi
git commit -m "auto: $(date -u +'%Y-%m-%dT%H:%M:%SZ')" --quiet
git push --quiet
echo "[obsidian-push] $(date -u +'%Y-%m-%d %H:%M UTC')"
