#!/bin/bash
# Sync monitoring scripts to GitHub: upmeister/hermes-infra
# Run via system crontab (hourly)

set -e

REPO_DIR="$HOME/.hermes/hermes-infra"
SCRIPT_DIR="$HOME/scripts"
HERMES_SCRIPT_DIR="$HOME/.hermes/scripts"
SYSTEMD_DIR="$HOME/.config/systemd/user"

# GitHub token. Приоритет: fine-grained PAT из .env (GH_TOKEN, scope workflow).
# gh auth token отдаёт OAuth (gho_) БЕЗ workflow scope → push workflow-файлов
# отклоняется ('refusing to allow an OAuth App to create or update workflow').
# Урок 2026-08-20: sync не мог запушить monitoring-tests.yml, пока не взяли GH_TOKEN.
if [ -f "$HOME/.hermes/.env" ]; then
    GH_TOKEN=$(grep -E '^GH_TOKEN=' "$HOME/.hermes/.env" | cut -d= -f2- | tr -d '\r')
fi
if [ -z "$GH_TOKEN" ]; then
    GH_TOKEN=$(gh auth token 2>/dev/null || echo "")
fi
if [ -z "$GH_TOKEN" ]; then
    echo "[sync-infra] ERROR: no GitHub token available"
    exit 1
fi
AUTH_URL="https://${GH_TOKEN}@github.com/upmeister/hermes-infra.git"

# Clone if not exists
if [ ! -d "$REPO_DIR/.git" ]; then
    git clone "$AUTH_URL" "$REPO_DIR" 2>/dev/null
fi

cd "$REPO_DIR"
# Pull with auth (rebase: в main пушат ещё heartbeat.sh и GitHub Actions heartbeat-check)
git pull --rebase --autostash "$AUTH_URL" main --quiet 2>/dev/null || true

# Copy current scripts. Glob *.sh: новый скрипт в ~/scripts попадает в бэкап сам,
# явные списки cp забываются (урок 2026-08-10: check-integrations.sh выпал из бэкапа).
cp "$SCRIPT_DIR"/*.sh scripts/ 2>/dev/null || true
cp "$HERMES_SCRIPT_DIR/health-analyzer.py" scripts/ 2>/dev/null || true
# Модули health-* обязательны: health-analyzer.py в репо без них битый (не запустится),
# а без них же нельзя прогнать CI-тесты (урок 2026-08-20: репо-копия была не self-contained).
for m in health_patterns.py health_decay.py health_netdata.py; do
  cp "$HERMES_SCRIPT_DIR/$m" scripts/ 2>/dev/null || true
done
# Тесты мониторинга — для CI (github-hosted). Копируются из ~/.hermes/tests/.
mkdir -p tests
cp "$HOME/.hermes/tests"/test_health_decay.py "$HOME/.hermes/tests"/test_health_patterns.py \
   "$HOME/.hermes/tests"/test_health_netdata.py "$HOME/.hermes/tests"/test_watchdog_alerts.py \
   tests/ 2>/dev/null || true
cp "$SYSTEMD_DIR/hermes-dashboard.service" systemd/ 2>/dev/null || true
cp "$SYSTEMD_DIR/hermes-gateway.service" systemd/ 2>/dev/null || true
cp "$SYSTEMD_DIR/telegram-path-manager.service" systemd/ 2>/dev/null || true
cp "$SYSTEMD_DIR/telegram-path-manager.timer" systemd/ 2>/dev/null || true

# Критичные скрипты из ~/.hermes/scripts: сеть/провайдеры/liveness — ядро выживания.
# (Конвенция 14.08: infra = наблюдатель + ядро восстановления; остальное — profile-sync.)
for f in telegram-path-manager.sh telegram-smart-proxy.py agentrouter-proxy.py \
         opencode-smart-proxy.py monitoring-bot-poller.py webhook.py \
         dashboard-liveness.sh gateway-liveness.sh health-check-integrations.sh; do
  cp "$HERMES_SCRIPT_DIR/$f" scripts/ 2>/dev/null || true
done
# webhook.py — в ~/scripts (НЕ ~/.hermes/scripts), копируем отдельно (библиотека poller'а)
cp "$SCRIPT_DIR/webhook.py" scripts/ 2>/dev/null || true
for u in telegram-smart-proxy.service agentrouter-proxy.service \
         opencode-smart-proxy.service monitoring-bot-poller.service; do
  cp "$SYSTEMD_DIR/$u" systemd/ 2>/dev/null || true
done

# Бэкап системного crontab в репо (ядро восстановления; был устаревший 24.07)
crontab -l > backups/crontab.txt 2>/dev/null || true

# Commit and push if changed
if ! git diff --quiet --exit-code; then
    git add -A
    git commit -m "sync: $(date -u +'%Y-%m-%d %H:%M UTC')" --quiet
    # Race: heartbeat.sh и GitHub Actions (heartbeat-check) тоже пушат в main.
    # Rebase перед повторным push + ретраи — иначе 'cannot lock ref refs/heads/main'.
    pushed=0
    for attempt in 1 2 3; do
        if git push "$AUTH_URL" main --quiet 2>/dev/null; then
            pushed=1
            break
        fi
        echo "[sync-infra] push attempt $attempt failed, rebase+retry"
        git pull --rebase --autostash "$AUTH_URL" main --quiet 2>/dev/null || true
        sleep 5
    done
    if [ "$pushed" -eq 1 ]; then
        echo "[sync-infra] pushed at $(date -u +'%Y-%m-%d %H:%M UTC')"
        # Обновляем бэкап crontab
        crontab -l > "$HOME/.hermes/backups/crontab-known-good.txt" 2>/dev/null
    else
        echo "[sync-infra] ERROR: push failed after 3 attempts"
    fi
fi
