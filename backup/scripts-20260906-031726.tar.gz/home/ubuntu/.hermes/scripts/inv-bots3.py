#!/usr/bin/env python3
"""Post-wave-3 remaining scan: UI-visible strings still not covered by an
exact-line rule. Filters out technical noise (codicon names, dom tags, data keys)."""
import json, re

SRC = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
REG = '/home/ubuntu/projects/hermes-desktop-ru/package/registry.json'

src = open(SRC, encoding='utf-8').read().split('\n')
rules = json.load(open(REG))
bot = [r for r in rules if 'hermes-bots/plugin.js' in r.get('file', '')]
covered_lines = set()
for r in bot:
    if len(r['before']) == 1:
        covered_lines.add(r['before'][0])

VIS = re.compile(r'\b(children|label|title|placeholder|description|text|hint|empty(?:Text)?|header(?:Text)?|caption|tooltip|aria-label)\b')
SCALAR = re.compile(r"'((?:[^'\\]|\\.)*?)'")

# technical tokens: codicon/spinner names, dom tags, css/class junk, single chars
TECH = set('bot generate upload pet refresh device-camera breathe trash calendar add gear close attach chevron-down bell hubot organization blobatar pdf file image legacy string function div span form iframe button slider input checkbox'.split())
TECH_EM = re.compile(r"^[ @:,\\.'/\\-]{1,3}$|^\\u[a-fA-F0-9]{4}$|^\\0$|^(div|span|button|form|iframe|img|label|input|select)$")

untr = []
for i, ln in enumerate(src, 1):
    if ln in covered_lines:
        continue
    m = VIS.search(ln)
    if not m:
        continue
    for mm in SCALAR.finditer(ln[m.end():m.end()+75]):
        v = mm.group(1)
        if not v:
            continue
        if v in TECH:
            continue
        if TECH_EM.match(v):
            continue
        if v == 'Bot Chat' or v == 'inbox-triage' or v.startswith('e.g.') or v.startswith('every ') or v.startswith('antigravity'):
            continue
        untr.append((i, v, ln.strip()[:115]))
        break

seen = {}
for i, v, s in untr:
    if v not in seen:
        seen[v] = (i, s)
print(f"осталось непокрытых видимых: {len(seen)}")
for v, (i, s) in sorted(seen.items(), key=lambda x: x[1][0]):
    print(f"{i}: {v!r}  << {s}")
