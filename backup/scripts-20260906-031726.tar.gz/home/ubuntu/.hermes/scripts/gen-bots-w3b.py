#!/usr/bin/env python3
"""Wave-3b: final 6 visible strings for hermes-bots."""
import json

SRC = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
lines = open(SRC, encoding='utf-8').read().split('\n')

SPEC = [
    (2439, [("'Blob face — drawn from the agent\\u2019s name'", "'Лицо-блоб — рисуется по имени агента'")]),
    (4051, [("'attached PDF'", "'прикреплённый PDF'"),
            ("'attached file'", "'прикреплённый файл'"),
            ("'attached image'", "'прикреплённое изображение'")]),
    (6572, [("children: 'Cancel'", "children: 'Отмена'")]),
    (9559, [("img.name || 'attached file'", "img.name || 'вложенный файл'")]),
    (9627, [("`${replies} ${replies === 1 ? 'reply' : 'replies'} · ${relativeTime(entries[entries.length - 1].entry.at)}`",
             "`${replies} ${replies === 1 ? 'ответ' : (replies >= 2 && replies <= 4 ? 'ответа' : 'ответов')} · ${relativeTime(entries[entries.length - 1].entry.at)}`")]),
]

rules = []
errors = []
for lineno, frags in SPEC:
    ln = lines[lineno - 1]
    new = ln
    for old, repl in frags:
        if old not in new:
            errors.append(f"L{lineno}: NOT FOUND {old!r}")
            continue
        new = new.replace(old, repl)
    if new == ln:
        errors.append(f"L{lineno}: no change")
        continue
    occurs = [i + 1 for i, l in enumerate(lines) if l == ln]
    if len(occurs) > 1:
        errors.append(f"L{lineno}: not unique ({occurs})")
        continue
    rules.append({"id": f"hermes-bots-w3b-{lineno}",
                  "file": "apps/desktop/src/plugins/hermes-bots/plugin.js",
                  "before": [ln], "after": [new]})

print(f"правил: {len(rules)}")
for e in errors: print(" -", e)
json.dump(rules, open('/tmp/bots-w3b.json', 'w'), ensure_ascii=False, indent=2)
print("saved -> /tmp/bots-w3b.json")
