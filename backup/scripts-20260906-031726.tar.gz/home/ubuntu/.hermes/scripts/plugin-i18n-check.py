#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""L4-плагинный матчер: сверка перевода плагинных i18n-бандлов.

Сравнивает plugins/*/i18n.ts (EN) с соответствующими ru-locales.ts (мод).
Слепая зона L3 (en.ts ≠ i18n.ts плагина) — этот скрипт её закрывает.

Usage:
  python3 plugin-i18n-check.py [путь к dev-клону] [путь к mod-репо]
"""
import re, sys, os

# Пути по умолчанию
DEV = os.path.expanduser('~/projects/hermes-agent-dev')
MOD = os.path.expanduser('~/projects/hermes-desktop-ru')

# Плагины с i18n-бандлами (канбан, боты...)
PLUGIN_I18N_MAP = {
    'hermes-bots': {
        'en': 'apps/desktop/src/plugins/hermes-bots/i18n.ts',
        'ru': 'package/files/ru-bots-locales.ts',
    },
}

# Ключи, которые намеренно не переводим
SKIP_KEYS = {'string', 'number', 'boolean', 'never', 'any'}

def parse_i18n_keys(text, label=''):
    """Извлекает пары (key_path, en_value) из i18n.ts плагина.
    Формат: keyName: 'value' или keyName: string (тип-аннотация)."""
    items = {}
    # Ищем строки key: 'value' / key: string / key: "value"
    pat = re.compile(r'^\s{4,}(\w[\w.]*?)\s*:\s*(?:\'([^\']+)\'|\"([^\"]+)\"|\w+\b)', re.M)
    for m in pat.finditer(text):
        k = m.group(1)
        v = m.group(2) or m.group(3) or 'TYPE_ONLY'
        if k not in SKIP_KEYS:
            items[k] = v
    return items

def parse_module_keys(text):
    """Извлекает пары (key, ru_value) из ru-locales.ts модуля.
    Формат: key: 'value',"""
    items = {}
    pat = re.compile(r'^\s{2,}(\w[\w.]*?):\s*\'([^\']+)\'', re.M)
    for m in pat.finditer(text):
        items[m.group(1)] = m.group(2)
    return items

def main():
    for plugin, paths in PLUGIN_I18N_MAP.items():
        en_path = os.path.join(DEV, paths['en'])
        ru_path = os.path.join(MOD, paths['ru'])
        
        if not os.path.exists(en_path):
            print(f"[{plugin}] EN source not found: {en_path}")
            continue
        if not os.path.exists(ru_path):
            print(f"[{plugin}] RU translation not found: {ru_path}")
            continue
        
        en_text = open(en_path, encoding='utf-8').read()
        ru_text = open(ru_path, encoding='utf-8').read()
        
        en_keys = parse_i18n_keys(en_text, f'{plugin}/en')
        ru_keys = parse_module_keys(ru_text)
        
        # Переводимые ключи (не TYPE_ONLY)
        translatable = {k: v for k, v in en_keys.items() if v != 'TYPE_ONLY'}
        
        missing = set(translatable.keys()) - set(ru_keys.keys())
        extra = set(ru_keys.keys()) - set(translatable.keys())
        
        print(f"\n=== {plugin} ===")
        print(f"  EN keys: {len(en_keys)} (translatable: {len(translatable)})")
        print(f"  RU keys: {len(ru_keys)}")
        print(f"  MISSING from ru-locales: {len(missing)}")
        for k in sorted(missing)[:30]:
            print(f"    ❌ {k}: \"{en_keys[k]}\"")
        if len(missing) > 30:
            print(f"    ... and {len(missing)-30} more")
        print(f"  EXTRA in ru-locales (not in EN): {len(extra)}")
        for k in sorted(extra)[:10]:
            print(f"    + {k}: \"{ru_keys[k]}\"")
        if len(extra) > 10:
            print(f"    ... and {len(extra)-10} more")
        
        if not missing and not extra:
            print("  ✅ FULLY COVERED")

if __name__ == '__main__':
    main()