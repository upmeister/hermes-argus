#!/usr/bin/env python3
"""opencode-smart-proxy — transparent proxy for geo-blocked AI hosts.

Listens on 127.0.0.1:8445 as an HTTP CONNECT proxy.
Gateway uses it via HTTPS_PROXY (see ~/.hermes/.env).

Routing:
  - opencode.ai   → try US (socks5 1084, sing-box-us, muse-spark)
                    → fallback EU (socks5 1080, sing-box vless)
                    → fallback direct (degraded: luna/muse 403, deepseek жив)
  - api.groq.com  → EU (socks5 1080) → fallback direct
  - api.github.com → US (1084) → EU (1080) → direct (direct блокируется DPI)
  - all other hosts      → direct (остальных провайдеров НЕ трогаем)
"""

import asyncio
import logging
import socket
import sys
import time
from typing import Optional, Tuple

from python_socks.async_.asyncio import Proxy as AsyncProxy

# ── Config ──────────────────────────────────────────────────────────────
LISTEN_HOST = "127.0.0.1"
LISTEN_PORT = 8445

# US (sing-box-us) — основной путь для opencode.ai (muse-spark contributor geo-блок)
US_PROXY_URL = "socks5://127.0.0.1:1084"
US_TIMEOUT = 5
# VLESS (sing-box) — Европа (запасной путь для opencode.ai, основной для groq)
VLESS_PROXY_URL = "socks5://127.0.0.1:1080"
VLESS_TIMEOUT = 5  # seconds; при таймауте → следующий fallback
# Стокгольм (AWS eu-north-1): все AI-сервисы доступны напрямую
# Каскады больше не нужны — убираем, остаётся только direct
OPENCODE_CASCADE = []
GROQ_CASCADE = []
GITHUB_CASCADE = []
CASCADE_FALLBACK_DIRECT = True  # при исчерпании каскада → direct (degraded)

# ── Logging ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
log = logging.getLogger("opencode-proxy")


# ── Connection helpers ──────────────────────────────────────────────────

async def connect_direct(host: str, port: int, timeout: float) -> Optional[Tuple[asyncio.StreamReader, asyncio.StreamWriter]]:
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=timeout,
        )
        return reader, writer
    except Exception:
        return None


async def connect_socks5(proxy_url: str, dest_host: str, dest_port: int, timeout: float) -> Optional[Tuple[asyncio.StreamReader, asyncio.StreamWriter]]:
    try:
        proxy = AsyncProxy.from_url(proxy_url)
        sock = await asyncio.wait_for(
            proxy.connect(dest_host=dest_host, dest_port=dest_port),
            timeout=timeout,
        )
        reader, writer = await asyncio.open_connection(sock=sock)
        return reader, writer
    except Exception as e:
        log.warning("SOCKS5 via %s failed: %s", proxy_url, e)
        return None


async def connect_best(target_host: str, target_port: int) -> Tuple[asyncio.StreamReader, asyncio.StreamWriter, str]:
    """Каскад прокси для opencode.ai (US→EU), groq (EU), остальное — direct."""
    t0 = time.monotonic()

    cascade = None
    if target_host == "opencode.ai":
        cascade = OPENCODE_CASCADE
    elif target_host == "api.groq.com":
        cascade = GROQ_CASCADE
    elif target_host == "api.github.com":
        cascade = GITHUB_CASCADE

    if cascade:
        for proxy_url in cascade:
            result = await connect_socks5(proxy_url, target_host, target_port, US_TIMEOUT)
            if result:
                elapsed = time.monotonic() - t0
                tag = "us-ss" if "1084" in proxy_url else "vless"
                return (*result, f"{tag} ({elapsed:.2f}s)")
            log.info("proxy %s failed for %s, next fallback", proxy_url, target_host)

        if not CASCADE_FALLBACK_DIRECT:
            raise ConnectionError(f"All proxies to {target_host} failed")

        log.info("All proxies failed for %s, falling back to direct (degraded)", target_host)

    result = await connect_direct(target_host, target_port, 8)
    if result:
        elapsed = time.monotonic() - t0
        return (*result, f"direct://{target_host}:{target_port} ({elapsed:.2f}s)")

    raise ConnectionError(f"Connection to {target_host}:{target_port} failed")


# ── Bidirectional relay ─────────────────────────────────────────────────

async def relay(src_reader: asyncio.StreamReader, src_writer: asyncio.StreamWriter,
                dst_reader: asyncio.StreamReader, dst_writer: asyncio.StreamWriter):
    async def pipe(r: asyncio.StreamReader, w: asyncio.StreamWriter):
        try:
            while True:
                data = await r.read(65536)
                if not data:
                    break
                w.write(data)
                await w.drain()
        except Exception:
            pass
        finally:
            try:
                w.close()
            except Exception:
                pass

    await asyncio.gather(
        pipe(src_reader, dst_writer),
        pipe(dst_reader, src_writer),
    )


# ── HTTP CONNECT handler ────────────────────────────────────────────────

async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    peer = writer.get_extra_info("peername")
    log.info("New connection from %s", peer)

    try:
        request_line = await asyncio.wait_for(reader.readline(), timeout=10)
        headers = {}
        while True:
            line = await asyncio.wait_for(reader.readline(), timeout=10)
            if line in (b"\r\n", b"\n", b""):
                break
            key, _, value = line.decode("latin-1").partition(":")
            headers[key.strip().lower()] = value.strip()

        parts = request_line.decode("latin-1").strip().split()
        if len(parts) < 3 or parts[0].upper() != "CONNECT":
            writer.write(b"HTTP/1.1 400 Bad Request\r\n\r\n")
            await writer.drain()
            writer.close()
            return

        host, _, port_str = parts[1].partition(":")
        port = int(port_str or 443)

        upstream_reader, upstream_writer, path = await connect_best(host, port)
        log.info("CONNECT %s:%s → %s", host, port, path)

        writer.write(b"HTTP/1.1 200 Connection established\r\n\r\n")
        await writer.drain()

        await relay(reader, writer, upstream_reader, upstream_writer)
    except Exception as e:
        log.info("CONNECT failed: %s", e)
        try:
            writer.write(b"HTTP/1.1 502 Bad Gateway\r\n\r\n")
            await writer.drain()
        except Exception:
            pass
        writer.close()


async def main():
    server = await asyncio.start_server(handle_client, LISTEN_HOST, LISTEN_PORT)
    log.info("opencode-smart-proxy listening on %s:%s", LISTEN_HOST, LISTEN_PORT)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(0)
