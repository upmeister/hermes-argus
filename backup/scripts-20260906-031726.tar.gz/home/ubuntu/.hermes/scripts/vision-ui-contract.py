#!/usr/bin/env python3
"""Vision UI-экстрактор с контрактом (24.08): temp 0, только буквальный текст,
запрет дополнений, [UNSURE] при сомнениях, кросс-чек грепом обязателен.

Usage: vision-ui-contract.py IMG [IMG...]
Канон для UI-скринов Hermes Desktop. После прогона каждую найденную строку
кросс-чекать: grep по /tmp/plugin-24.js, en-24.ts, бандлу — строка, которой
нет в коде, = подозрение на галлюцинацию (прецедент: «Create Channel»)."""
import json, os, subprocess, sys, base64, time

def load_env():
    p = os.path.expanduser("~/.hermes/.env")
    if os.path.exists(p):
        for line in open(p):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k, v.strip().strip('"').strip("'"))

load_env()

CONTRACT = (
    "Ты — инструмент извлечения текста из скриншотов интерфейса. ПРАВИЛА:\n"
    "1. Переписывай ТОЛЬКО текст, который буквально виден на изображении, символ в символ.\n"
    "2. ЗАПРЕЩЕНО угадывать или дополнять типичные элементы интерфейса, которых нет на картинке.\n"
    "3. Если текст нечитаем или ты не уверен, что он есть на скрине — пометь его суффиксом [UNSURE].\n"
    "4. Для каждой строки укажи зону: button/input/menu/tab/status/tooltip/dialog/list/other.\n"
    "5. Интересуют ВСЕ видимые строки, но особенно: английские строки в русском UI и кривые переводы.\n"
    "Ответ строго JSON: {\"items\":[{\"text\":\"...\",\"zone\":\"...\"}],\"notes\":\"...\"}"
)

def ask(path):
    b64 = base64.b64encode(open(path, "rb").read()).decode()
    for use_json_fmt in (True, False):  # json_object валит -> fallback на текст
        payload = {
            "model": "qwen/qwen3.6-27b",
            "temperature": 0,
            "max_tokens": 2000,
            "messages": [{"role": "user", "content": [
                {"type": "text", "text": CONTRACT},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}}]}]
        }
        if use_json_fmt:
            payload["response_format"] = {"type": "json_object"}
        for attempt in range(3):  # 429 (TPM/RPM) -> подождать
            req = subprocess.run(
                ["curl", "-sS", "-m", "60",
                 "https://api.groq.com/openai/v1/chat/completions",
                 "-H", f"Authorization: Bearer {os.environ['GROQ_API_KEY']}",
                 "-H", "Content-Type: application/json", "-d", json.dumps(payload)],
                capture_output=True, text=True, timeout=80)
            try:
                d = json.loads(req.stdout)
            except Exception:
                if attempt < 2:
                    time.sleep(15); continue
                return {"items": [], "notes": f"HTTP ERROR {req.stdout[:200]}"}
            if "choices" not in d:
                if "rate" in str(d.get("error", "")).lower() and attempt < 2:
                    time.sleep(20); continue
                if use_json_fmt:
                    break  # validation fail -> пробуем без response_format
                return {"items": [], "notes": f"API ERROR {str(d)[:200]}"}
            content = d["choices"][0]["message"]["content"]
            try:
                return json.loads(content)
            except Exception:
                if use_json_fmt:
                    break  # модель вернула не-JSON -> fallback
                return {"items": [{"text": line, "zone": "?"}
                                  for line in content.splitlines() if line.strip()],
                        "notes": "raw text (не JSON)"}
    return {"items": [], "notes": "all fallbacks failed"}

for p in sys.argv[1:]:
    r = ask(p)
    print(f"===== {p} =====")
    for it in r.get("items", []):
        print(f"[{it.get('zone', '?')}] {it.get('text', '')}")
    if r.get("notes"):
        print("NOTE:", r["notes"])
    time.sleep(3)
