#!/usr/bin/env python3
"""telegram-smart-proxy — transparent failover proxy for Telegram Bot API.

Listens on 127.0.0.1:8444 as an HTTP CONNECT proxy.
Gateway connects here once, proxy handles path selection:
  1. Direct IPs (tried in order, 5s timeout each)
  2. VLESS (sing-box 127.0.0.1:1080, urltest cascades NL/ES/CZ/UK servers)
  3. Tor SOCKS5 (127.0.0.1:9050)

No gateway restarts needed. No .env changes on failover.
Add tiers by appending to FALLBACK_CHAIN.
"""

import asyncio
import logging
import socket
import sys
import time
from typing import Optional, Tuple

from python_socks.async_.asyncio import Proxy as AsyncProxy

# ── Config ──────────────────────────────────────────────────────────────
LISTEN_HOST = "127.0.0.1"
LISTEN_PORT = 8444

# Tier 1: direct IPs — try each, first to respond wins
DIRECT_TARGETS = [
    ("149.154.167.220", 443),   # DC2 Amsterdam (working)
    ("149.154.166.110", 443),   # DC2 Amsterdam (working)
    ("149.154.175.53", 443),    # DC1 Miami
    ("91.108.56.130", 443),     # DC5 Singapore
]
DIRECT_TIMEOUT = 3  # seconds per IP attempt (was 5, reduced for faster failover)

# Tier 2: VLESS (sing-box 127.0.0.1:1080, urltest каскадит 4 сервера NL/ES/CZ/UK)
VLESS_PROXY_URL = "socks5://127.0.0.1:1080"
VLESS_TIMEOUT = 8

# Tier 3: Tor SOCKS5
TOR_PROXY_URL = "socks5://127.0.0.1:9050"
TOR_TIMEOUT = 15

# Target hostname for TLS SNI (must match what gateway requests)
TELEGRAM_HOST = "api.telegram.org"
TELEGRAM_PORT = 443

# ── Logging ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
log = logging.getLogger("telegram-proxy")


# ── Connection helpers ──────────────────────────────────────────────────

async def connect_direct(host: str, port: int, timeout: float) -> Optional[Tuple[asyncio.StreamReader, asyncio.StreamWriter]]:
    """Try a direct TCP connection to a specific IP."""
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=timeout,
        )
        log.debug("Direct connection to %s:%s succeeded", host, port)
        return reader, writer
    except Exception:
        return None


async def connect_socks5(proxy_url: str, dest_host: str, dest_port: int, timeout: float) -> Optional[Tuple[asyncio.StreamReader, asyncio.StreamWriter]]:
    """Connect through a SOCKS5 proxy."""
    try:
        proxy = AsyncProxy.from_url(proxy_url)
        sock = await asyncio.wait_for(
            proxy.connect(dest_host=dest_host, dest_port=dest_port),
            timeout=timeout,
        )
        reader, writer = await asyncio.open_connection(sock=sock)
        log.info("SOCKS5 connection to %s:%s succeeded (via %s)", dest_host, dest_port, proxy_url)
        return reader, writer
    except Exception as e:
        log.warning("SOCKS5 connection via %s failed: %s", proxy_url, e)
        return None


async def connect_best(target_host: str, target_port: int) -> Tuple[asyncio.StreamReader, asyncio.StreamWriter, str]:
    """Try all paths in order. Returns (reader, writer, path_description)."""
    t0 = time.monotonic()

    # If target is Telegram API, use failover chain
    if target_host == TELEGRAM_HOST:
        # Tier 1: direct IPs
        for ip, port in DIRECT_TARGETS:
            result = await connect_direct(ip, target_port, DIRECT_TIMEOUT)
            if result:
                elapsed = time.monotonic() - t0
                return (*result, f"direct://{ip}:{target_port} ({elapsed:.2f}s)")

        # Tier 2: VLESS (sing-box socks, urltest-каскад по серверам)
        log.info("Direct IPs failed, trying VLESS ...")
        result = await connect_socks5(VLESS_PROXY_URL, target_host, target_port, VLESS_TIMEOUT)
        if result:
            elapsed = time.monotonic() - t0
            return (*result, f"vless ({elapsed:.2f}s)")

        # Tier 3: Tor
        log.info("VLESS failed, trying Tor ...")
        result = await connect_socks5(TOR_PROXY_URL, target_host, target_port, TOR_TIMEOUT)
        if result:
            elapsed = time.monotonic() - t0
            return (*result, f"tor ({elapsed:.2f}s)")

        raise ConnectionError(f"All paths to {target_host} failed")

    # Non-Telegram target: direct DNS resolution only
    log.info("Non-Telegram target %s:%s, using DNS direct connection", target_host, target_port)
    result = await connect_direct(target_host, target_port, DIRECT_TIMEOUT)
    if result:
        elapsed = time.monotonic() - t0
        return (*result, f"dns://{target_host}:{target_port} ({elapsed:.2f}s)")

    raise ConnectionError(f"Connection to {target_host}:{target_port} failed")


# ── Bidirectional relay ─────────────────────────────────────────────────

async def relay(src_reader: asyncio.StreamReader, src_writer: asyncio.StreamWriter,
                dst_reader: asyncio.StreamReader, dst_writer: asyncio.StreamWriter):
    """Bidirectional relay between client and upstream."""
    async def pipe(r: asyncio.StreamReader, w: asyncio.StreamWriter, label: str):
        try:
            while True:
                data = await r.read(65536)
                if not data:
                    break
                w.write(data)
                await w.drain()
        except Exception:
            pass
        finally:
            try:
                w.close()
            except Exception:
                pass

    await asyncio.gather(
        pipe(src_reader, dst_writer, "→upstream"),
        pipe(dst_reader, src_writer, "←upstream"),
    )


# ── HTTP CONNECT handler ────────────────────────────────────────────────

async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    peer = writer.get_extra_info("peername")
    log.info("New connection from %s", peer)

    try:
        # Read the CONNECT request line
        request_line = await asyncio.wait_for(reader.readline(), timeout=10)
        request_line = request_line.decode("utf-8", errors="replace").strip()

        if not request_line.startswith("CONNECT "):
            log.warning("Bad request from %s: %s", peer, request_line)
            writer.write(b"HTTP/1.1 400 Bad Request\r\n\r\n")
            await writer.drain()
            writer.close()
            return

        # Parse CONNECT host:port
        # Format: CONNECT api.telegram.org:443 HTTP/1.1
        parts = request_line.split()
        if len(parts) < 2:
            writer.close()
            return

        target = parts[1]  # "api.telegram.org:443"
        target_host, _, target_port_str = target.partition(":")
        target_port = int(target_port_str) if target_port_str else 443
        log.info("CONNECT request: %s:%s", target_host, target_port)

        # Read and discard headers until empty line
        while True:
            header = await asyncio.wait_for(reader.readline(), timeout=5)
            if header in (b"\r\n", b"\n", b""):
                break

        # Connect through best path
        upstream_reader, upstream_writer, path_info = await connect_best(target_host, target_port)
        log.info("Connected via %s for %s", path_info, peer)

        # Send 200 to client — tunnel established
        writer.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
        await writer.drain()

        # Relay
        await relay(reader, writer, upstream_reader, upstream_writer)

    except asyncio.TimeoutError:
        log.warning("Timeout from %s", peer)
    except ConnectionError as e:
        log.error("Connection failed for %s: %s", peer, e)
        try:
            writer.write(b"HTTP/1.1 502 Bad Gateway\r\n\r\n")
            await writer.drain()
        except Exception:
            pass
    except Exception as e:
        log.error("Error handling %s: %s", peer, e, exc_info=True)
    finally:
        try:
            writer.close()
        except Exception:
            pass
        log.info("Connection closed for %s", peer)


# ── Main ────────────────────────────────────────────────────────────────

async def main():
    server = await asyncio.start_server(handle_client, LISTEN_HOST, LISTEN_PORT)
    log.info("Telegram Smart Proxy listening on %s:%s", LISTEN_HOST, LISTEN_PORT)
    log.info("Failover chain: %d direct IPs → Tor SOCKS5", len(DIRECT_TARGETS))

    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("Shutting down")
