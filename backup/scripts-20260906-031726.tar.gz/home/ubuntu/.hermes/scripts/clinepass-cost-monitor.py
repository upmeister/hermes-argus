#!/usr/bin/env python3
"""ClinePass usage & cost monitor.

Usage:
  python3 clinepass-cost-monitor.py          → single probe + report
  python3 clinepass-cost-monitor.py --daemon → update CSV + report (for cron)

Does a tiny probe call to the ClinePass API, records cost from the response,
and reports subscription health. Zero dependencies beyond stdlib.
"""

import json
import os
import sys
import time
from datetime import datetime, timezone
from urllib.request import Request, urlopen

# ── Config ──────────────────────────────────────────────────────────────────
API_KEY_ENV="CLINE_API_KEY"
API_URL = "https://api.cline.bot/api/v1/chat/completions"
COST_DB = os.path.expanduser("~/.hermes/logs/clinepass-cost.csv")
MODEL = "cline-pass/deepseek-v4-flash"
PROBE_MSG = "ok"      # shortest valid request
PROBE_TOKENS = 1        # approximate token count (1 token = minimal probe)

# ── Probe ───────────────────────────────────────────────────────────────────
def _load_api_key() -> str:
    """Read CLINE_API_KEY from .env or environment."""
    key = os.environ.get(API_KEY_ENV)
    if key:
        return key
    # Fallback: read from ~/.hermes/.env
    env_path = os.path.expanduser("~/.hermes/.env")
    if os.path.isfile(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith(f"{API_KEY_ENV}="):
                    return line.split("=", 1)[1]
    raise RuntimeError(f"{API_KEY_ENV} not set in environment or ~/.hermes/.env")

def probe() -> dict:
    """Call the Chat Completions API and return the parsed response body."""
    key = _load_api_key()

    body = json.dumps({
        "model": MODEL,
        "messages": [{"role": "user", "content": PROBE_MSG}],
        "max_tokens": 1,
        "temperature": 0,
    }).encode()

    req = Request(API_URL, data=body, method="POST")
    req.add_header("Authorization", f"Bearer {key}")
    req.add_header("Content-Type", "application/json")

    raw = urlopen(req, timeout=15).read()
    parsed = json.loads(raw.decode())

    # ClinePass wraps in {data: ..., success: true}
    if "data" in parsed:
        return parsed["data"]
    if "error" in parsed:
        err_msg = parsed["error"] if isinstance(parsed["error"], str) else str(parsed["error"])
        raise RuntimeError(f"API error: {err_msg}")
    return parsed


class ProbeError(Exception):
    """Raised when the probe call itself fails (network, HTTP error)."""
    pass


def extract_cost(response: dict) -> dict:
    """Extract usage/cost info from a ChatCompletion response."""
    usage = response.get("usage") or {}
    model = response.get("model", "unknown")
    provider = response.get("provider", "unknown")
    return {
        "model": model,
        "provider": provider,
        "cost": usage.get("cost", 0),
        "total_tokens": usage.get("total_tokens", 0),
        "prompt_tokens": usage.get("prompt_tokens", 0),
        "completion_tokens": usage.get("completion_tokens", 0),
        "cached_tokens": (usage.get("prompt_tokens_details") or {}).get("cached_tokens", 0),
    }


# ── CSV Logging ─────────────────────────────────────────────────────────────
def append_to_db(entry: dict):
    """Append one cost record to the CSV file (create if absent)."""
    now = datetime.now(timezone.utc)
    row = {
        "ts": now.isoformat(),
        "cost": entry["cost"],
        "total_tokens": entry["total_tokens"],
        "prompt_tokens": entry["prompt_tokens"],
        "completion_tokens": entry["completion_tokens"],
        "cached_tokens": entry["cached_tokens"],
        "model": entry["model"],
        "provider": entry["provider"],
        "alive": entry["alive"],
    }
    header = list(row.keys())
    exists = os.path.isfile(COST_DB)
    with open(COST_DB, "a") as f:
        if not exists:
            f.write("# clinepass cost probe log\n")
            f.write(",".join(header) + "\n")
        f.write(",".join(str(row[k]) for k in header) + "\n")


def read_db() -> list[dict]:
    """Read all records from the CSV."""
    if not os.path.isfile(COST_DB):
        return []
    rows = []
    with open(COST_DB) as f:
        header = None
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if header is None:
                header = line.split(",")
                continue
            vals = line.split(",")
            rows.append(dict(zip(header, vals)))
    return rows


# ── Report ──────────────────────────────────────────────────────────────────
def report(rows: list[dict], entry: dict) -> str:
    """Build a human-readable report line."""
    now = datetime.now(timezone.utc)
    # Today's costs
    today = now.strftime("%Y-%m-%d")
    alive_rows = [r for r in rows if r.get("alive") == "1"]
    today_alive = [r for r in alive_rows if r["ts"].startswith(today)]
    today_cost = sum(float(r["cost"]) for r in today_alive)
    today_tokens = sum(int(r["total_tokens"]) for r in today_alive)

    # All-time (only alive rows for cost)
    total_cost = sum(float(r["cost"]) for r in alive_rows)
    total_tokens = sum(int(r["total_tokens"]) for r in alive_rows)
    uptime_pct = len(alive_rows) * 100 // len(rows) if rows else 0

    is_ok = entry.get("alive", 0) == 1
    lines = [
        f"📊 ClinePass cost monitor — {today}",
        f"  Uptime: {uptime_pct}% ({len(alive_rows)}/{len(rows)} probes OK)",
    ]
    if is_ok:
        lines += [
            f"  Probe:  cost=${entry['cost']:.8f}  tokens={entry['total_tokens']}",
            f"  Model:  {entry['model']}  Route:  {entry['provider']}",
            f"",
            f"  Today:  ${today_cost:.6f} ({today_tokens} tokens)",
            f"  Total:  ${total_cost:.6f} ({total_tokens} tokens logged)",
            f"  Probes: {len(alive_rows)} calls",
        ]
    else:
        lines += [
            f"  Probe:  FAILED ({entry.get('provider', 'unknown')})",
            f"  Today:  ${today_cost:.6f} ({today_tokens} tokens logged)",
        ]
    return "\n".join(lines)


# ── Main ────────────────────────────────────────────────────────────────────
def main():
    # Auto-enable daemon mode when stdout is not a terminal (cron, pipes, bot-chat)
    daemon_mode = "--daemon" in sys.argv or not sys.stdout.isatty()
    try:
        resp = probe()
        cost_info = extract_cost(resp)
        cost_info["alive"] = 1

        if daemon_mode:
            append_to_db(cost_info)

        rows = read_db()
        rpt = report(rows, cost_info)
        print(rpt)
        return 0
    except Exception as e:
        err_report = [
            f"⚠️ ClinePass probe FAILED: {e}",
        ]
        if daemon_mode:
            # Log the failure even on error — alive=0 keeps timeline
            fail_entry = {
                "cost": 0, "total_tokens": 0,
                "prompt_tokens": 0, "completion_tokens": 0,
                "cached_tokens": 0,
                "model": "error", "provider": str(e)[:50],
                "alive": 0,
            }
            append_to_db(fail_entry)
            err_report.append(f"  (logged as alive=0)")

        rows = read_db()
        alive_rows = [r for r in rows if r.get("alive") == "1"]
        uptime_pct = 0
        if rows:
            uptime_pct = len(alive_rows) * 100 // len(rows)
        err_report.append(f"  Uptime: {uptime_pct}% ({len(alive_rows)}/{len(rows)} probes OK)")
        print("\n".join(err_report))
        return 1


if __name__ == "__main__":
    sys.exit(main())