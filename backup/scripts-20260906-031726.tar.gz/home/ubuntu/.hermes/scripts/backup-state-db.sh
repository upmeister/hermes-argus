#!/bin/bash
set -e

# Daily state.db backup — consistent snapshot via SQLite backup API
# Run from system crontab: 0 4 * * * /home/ubuntu/.hermes/scripts/backup-state-db.sh

HERMES_HOME="${HERMES_HOME:-$HOME/.hermes}"
BACKUP_DIR="$HERMES_HOME/backups/state-db"
mkdir -p "$BACKUP_DIR"

DEST="$BACKUP_DIR/state.db.$(date +%Y%m%d-%H%M%S)"

python3 - "$DEST" << 'PYEOF'
import sqlite3, sys
src_path = "/home/ubuntu/.hermes/state.db"
dst_path = sys.argv[1]
src = sqlite3.connect(src_path)
dst = sqlite3.connect(dst_path)
src.backup(dst)
dst.close()
src.close()
PYEOF

# Compress
gzip "$DEST"

# Keep 7 days, delete older
find "$BACKUP_DIR" -name 'state.db.*.gz' -mtime +7 -delete

echo "Backup saved: ${DEST}.gz ($(du -sh "${DEST}.gz" | cut -f1))"