#!/usr/bin/env python3
"""Prepare rules for filter-menu.tsx (sessions filter pane) — exact-line anchors.
Duplicated identical lines -> all:true. PR/Pull request kept as technical term."""
import json

SRC = '/tmp/fresh-src/filter-menu.tsx'
lines = open(SRC, encoding='utf-8').read().split('\n')

SPEC = [
    (75,  "label: 'Updated'", "label: 'Обновлено'"),
    (76,  "label: 'Project'", "label: 'Проект'"),
    (77,  "label: 'Status'", "label: 'Статус'"),
    (78,  "label: 'Profile'", "label: 'Профиль'"),
    (82,  "label: 'Updated'", "label: 'Обновлено'"),
    (83,  "label: 'Created'", "label: 'Создано'"),
    (84,  "label: 'Status'", "label: 'Статус'"),
    (85,  "label: 'Tokens'", "label: 'Токены'"),
    (86,  "label: 'Cost'", "label: 'Стоимость'"),
    (87,  "label: 'Manual'", "label: 'Вручную'"),
    (91,  "label: 'Updated'", "label: 'Обновлено'"),
    (92,  "label: 'Preview'", "label: 'Превью'"),
    (93,  "label: 'Tokens'", "label: 'Токены'"),
    (94,  "label: 'Cost'", "label: 'Стоимость'"),
    # PR/Pull request — технический термин, оставляем
    (100, "label: 'Open'", "label: 'Открытые'"),
    (101, "label: 'Draft'", "label: 'Черновик'"),
    (102, "label: 'Merged'", "label: 'Слитые'"),
    (103, "label: 'Closed'", "label: 'Закрытые'"),
    (104, "label: 'No PR'", "label: 'Без PR'"),
    (108, "label: 'Needs input'", "label: 'Нужен ваш ответ'"),
    (109, "label: 'Working'", "label: 'Работает'"),
    (111, "label: 'Draft'", "label: 'Черновик'"),
    (110, "label: 'Unread'", "label: 'Непрочитанное'"),
    (112, "label: 'Idle'", "label: 'Ожидание'"),
    (230, "Grouping", "Группировка"),
    (249, "Ordering", "Сортировка"),
    (263, "Show", "Показывать"),
    (281, "label: 'Inbox style'", "label: 'Стиль «Почта»'"),
    (288, "Filters", "Фильтры"),
    (291, "Status", "Статус"),
    # Pull request (308) — технический термин, оставляем
    (323, "Profile", "Профиль"),
    (350, "Project", "Проект"),
    (385, "label: 'Archived'", "label: 'В архиве'"),
    (408, "'Expand all' : 'Collapse all'", "'Развернуть все' : 'Свернуть все'"),
    (412, "Mark all as read", "Отметить всё прочитанным"),
]

rules = []
errors = []
for lineno, old, repl in SPEC:
    ln = lines[lineno - 1]
    if old not in ln:
        errors.append(f"L{lineno}: NOT FOUND {old!r}")
        continue
    new = ln.replace(old, repl)
    if new == ln:
        errors.append(f"L{lineno}: no change")
        continue
    occurs = [i + 1 for i, l in enumerate(lines) if l == ln]
    is_all = len(occurs) > 1
    rid = f"filter-menu-{lineno}" + ("-all" if is_all else "")
    rules.append({"id": rid, "file": "apps/desktop/src/app/chat/sidebar/filter-menu.tsx",
                  "before": [ln], "after": [new], **({"all": True} if is_all else {})})

print(f"правил: {len(rules)}  (all-дублей: {sum(1 for r in rules if r.get('all'))})")
for e in errors: print(" -", e)
json.dump(rules, open('/tmp/filter-menu-rules.json', 'w'), ensure_ascii=False, indent=2)
print("saved -> /tmp/filter-menu-rules.json")
