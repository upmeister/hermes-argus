#!/usr/bin/env python3
"""Upstream watch sensor for hermes-desktop-ru.

Monitors NousResearch/hermes-agent: new releases, apps/desktop commits,
en.ts content hash, AND UI literals in the bots plugin + inter-agent thread
components (level 1: new/changed hardcoded strings the mod may not cover).
Emits CHANGED exactly once per new state (stable output between ticks =>
monitor suppresses repeat agent runs), and only OUTSIDE DeepSeek peak hours
(01:00-04:00, 06:00-10:00 UTC). The cron agent updates state.json after
analysis; pending file holds states seen during peak.

Источник файлов — shallow sparse-клон (upstream-repo/): git fetch при смене
commits; gh api contents троттлится (gitmon), поэтому не используется.
"""
import base64, json, subprocess, hashlib, os, sys, datetime, time, urllib.request

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "upstream-watch"))
from literals import extract, load_covered, uncovered

BASE = os.path.expanduser("~/.hermes/scripts/upstream-watch")
CACHE = os.path.join(BASE, "cache")
os.makedirs(BASE, exist_ok=True)
os.makedirs(CACHE, exist_ok=True)
STATE = os.path.join(BASE, "state.json")
PENDING = os.path.join(BASE, "pending")
RAW = "https://raw.githubusercontent.com/NousResearch/hermes-agent/main/"

FILES = [
    "apps/desktop/src/i18n/en.ts",
    # Bot Mode (29.08, b2e5b1d42007): plugin.js УДАЛЁН — TSX + плагинный i18n-бандл
    # 02.09: полный каталог — каждый новый TSX-файл ботов = слепая зона (урок 17 скринов)
    "apps/desktop/src/plugins/hermes-bots/i18n.ts",
    "apps/desktop/src/plugins/hermes-bots/canonical-chat.ts",
    "apps/desktop/src/plugins/hermes-bots/group-chat-parts.tsx",
    "apps/desktop/src/plugins/hermes-bots/cron.tsx",
    "apps/desktop/src/plugins/hermes-bots/roster-pane.tsx",
    "apps/desktop/src/plugins/hermes-bots/create-dialog.tsx",
    "apps/desktop/src/plugins/hermes-bots/avatar-picker.tsx",
    "apps/desktop/src/plugins/hermes-bots/avatar.tsx",
    "apps/desktop/src/plugins/hermes-bots/model-picker.tsx",
    "apps/desktop/src/plugins/hermes-bots/plugin.tsx",
    "apps/desktop/src/plugins/hermes-bots/bot-row.tsx",
    "apps/desktop/src/plugins/hermes-bots/data.ts",
    "apps/desktop/src/plugins/hermes-bots/roster-sections.tsx",
    "apps/desktop/src/plugins/hermes-bots/profile-config.tsx",
    "apps/desktop/src/plugins/hermes-bots/edit-profile-dialog.tsx",
    "apps/desktop/src/plugins/hermes-bots/group-chat-view.tsx",
    "apps/desktop/src/plugins/hermes-bots/session-sweep.ts",
    "apps/desktop/src/plugins/hermes-bots/skills-hub.tsx",
    "apps/desktop/src/plugins/hermes-bots/mcp-setup.tsx",
    "apps/desktop/src/plugins/hermes-bots/group-rounds.ts",
    "apps/desktop/src/plugins/hermes-bots/group-membership.ts",
    "apps/desktop/src/plugins/hermes-bots/labels.ts",
    "apps/desktop/src/plugins/hermes-bots/hygiene.ts",
    "apps/desktop/src/plugins/hermes-bots/dialog-parts.tsx",
    "apps/desktop/src/plugins/hermes-bots/routing.ts",
    "apps/desktop/src/plugins/hermes-bots/roster-actions.ts",
    "apps/desktop/src/plugins/hermes-bots/profile-ops.ts",
    "apps/desktop/src/components/assistant-ui/thread/agent-delivery.tsx",
    "apps/desktop/src/components/assistant-ui/thread/user-message.tsx",
    "apps/desktop/src/components/assistant-ui/thread/assistant-message.tsx",
    # поле-настройки (28.08, раздел Browser): псевдо-i18n вне en.ts —
    # SHA-мониторинг + литералы, чтобы новые разделы настроек не проходили мимо L1
    "apps/desktop/src/app/settings/constants.ts",
]

def gh(args):
    return subprocess.run(["gh", "api", *args], capture_output=True,
                          text=True, timeout=60).stdout.strip()

def fetch_raw(path):
    """404 (файл удалён в апстриме) — НЕ фолбэчим на кэш молча: это сигнал
    массовой смерти правил (урок 29.08: plugin.js удалён, L1 врал 2 дня)."""
    last = None
    for delay in (10, 30):
        try:
            req = urllib.request.Request(RAW + path,
                                         headers={"User-Agent": "hermes-ru-mod-watch"})
            resp = urllib.request.urlopen(req, timeout=30)
            return resp.read()
        except urllib.error.HTTPError as e:
            if e.code == 404:
                raise RuntimeError(f"DEPRECATED: {path} не существует в main (404) — файл удалён, проверь FILES")
            last = e
            time.sleep(delay)
        except Exception as e:
            last = e
            time.sleep(delay)
    raise RuntimeError(f"raw fetch failed for {path}: {last}")

def get_contents(com_sig):
    """Кэш при неизменном com_sig; иначе raw.githubusercontent -> кэш.
    При сетевых ошибках graceful-фолбек на прошлый кэш."""
    cache_paths = [os.path.join(CACHE, p.split("/")[-1]) for p in FILES]
    sig_file = os.path.join(CACHE, "_com_sig")
    have = all(os.path.exists(c) for c in cache_paths)
    cached_sig = open(sig_file).read().strip() if os.path.exists(sig_file) else None
    if have and cached_sig == com_sig:
        return {p: open(c, "rb").read() for p, c in zip(FILES, cache_paths)}
    out = {}
    for p, c in zip(FILES, cache_paths):
        try:
            data = fetch_raw(p)
        except Exception:
            if os.path.exists(c):
                data = open(c, "rb").read()  # graceful: прошлый кэш
            else:
                raise
        out[p] = data
        with open(c, "wb") as f:
            f.write(data)
    with open(sig_file, "w") as f:
        f.write(com_sig)
    return out

def is_peak(now):
    h = now.hour
    return (1 <= h < 4) or (6 <= h < 10)

def main():
    try:
        rel = gh(["repos/NousResearch/hermes-agent/releases?per_page=5",
                  "--jq", "[.[] | {t: .tag_name, d: .published_at[:10]}]"])
        com = gh(["repos/NousResearch/hermes-agent/commits?path=apps/desktop&per_page=15",
                  "--jq", "[.[] | .sha[:12]]"])
        com_sig = hashlib.sha256(com.encode()).hexdigest()[:16]

        prev = {}
        if os.path.exists(STATE):
            with open(STATE) as f:
                prev = json.load(f)

        contents = get_contents(com_sig)
        en_sha = hashlib.sha256(contents[FILES[0]]).hexdigest()[:16]

        covered = load_covered()
        lit = []
        for path in FILES[1:]:
            lit += extract(contents[path].decode('utf-8', 'replace'), path.split('/')[-1])
        new_lit = uncovered(lit, covered)
        lit_sig = hashlib.sha256(repr(new_lit[:60]).encode()).hexdigest()[:16]

        state_hash = hashlib.sha256((rel + com + en_sha + lit_sig).encode()).hexdigest()[:16]

        if prev.get("hash") == state_hash:
            print(f"UNCHANGED {state_hash}")
            return

        now = datetime.datetime.now(datetime.timezone.utc)
        if is_peak(now):
            if not os.path.exists(PENDING):
                with open(PENDING, "w") as f:
                    f.write(state_hash)
            print(f"UNCHANGED {state_hash}")
            return

        if os.path.exists(PENDING):
            os.remove(PENDING)

        print(f"CHANGED {state_hash}")
        print("COM_SIG:", com_sig)
        print("RELEASES:", rel[:800])
        print("COMMITS:", com[:1200])
        print("EN_TS_SHA:", en_sha)
        print("LITERALS_UNCOVERED:", len(new_lit))
        for label, n, s in new_lit[:40]:
            print(f"  {label}:{n}: {s}")
    except Exception as e:
        # stable output on failure -> silent tick, no agent wake
        print(f"UNCHANGED error {type(e).__name__}")

if __name__ == "__main__":
    main()
