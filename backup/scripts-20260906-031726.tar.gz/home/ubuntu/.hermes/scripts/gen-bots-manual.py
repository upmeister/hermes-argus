#!/usr/bin/env python3
"""Append remaining hand-picked rules to /tmp/bots-overrides.json (schedule labels,
single-line jsx props). Values must byte-match the actual file lines."""
import json

path = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
lines = open(path, encoding='utf-8').read().split('\n')

def add_rule(rules, val, ru, prop=None, all_=False):
    """find the real line containing prop:'val' (or just val) and build rule."""
    if prop:
        pat = f"{prop}: '{val}'"
    else:
        pat = f"'{val}'"
    idxs = [i for i, l in enumerate(lines) if pat in l]
    if not idxs:
        print(f"  NOTFOUND: {pat[:70]}")
        return
    src = lines[idxs[0]]
    dst = src.replace(pat, (f"{prop}: '{ru}'" if prop else f"'{ru}'"))
    rule = {"id": f"hermes-bots-man-{val[:20].replace(' ','_')}",
            "file": "apps/desktop/src/plugins/hermes-bots/plugin.js",
            "before": [src], "after": [dst]}
    if all_ or len(idxs) > 1:
        rule["all"] = True
    rules.append(rule)

rules = json.load(open('/tmp/bots-overrides.json'))

# schedule labels (object rows, line 7721-7727 + 7883)
add_rule(rules, 'Once, in\\u2026', 'Один раз, через…', prop='label')
add_rule(rules, 'Every hour', 'Каждый час', prop='label')
add_rule(rules, 'Every day', 'Каждый день', prop='label')
add_rule(rules, 'Weekdays', 'По будням', prop='label')
add_rule(rules, 'Every week', 'Каждую неделю', prop='label')
add_rule(rules, 'Every month', 'Каждый месяц', prop='label')
add_rule(rules, 'Interval', 'Интервал', prop='label')
add_rule(rules, 'days', 'дней', prop='label')
add_rule(rules, 'minutes', 'минут', prop='label')
add_rule(rules, 'minutes from now', 'минут от текущего', prop='label')
add_rule(rules, 'hours', 'часов', prop='label')
add_rule(rules, 'hours from now', 'часов от текущего', prop='label')
add_rule(rules, 'days from now', 'дней от текущего', prop='label')
# weekday labels
for val, ru in [('Monday','Понедельник'),('Tuesday','Вторник'),('Wednesday','Среда'),
                ('Thursday','Четверг'),('Friday','Пятница'),('Saturday','Суббота'),
                ('Sunday','Воскресенье')]:
    add_rule(rules, val, ru, prop='label')

# single-line jsx props
add_rule(rules, 'set up \\u2713', 'настроено \\u2713', prop='children')
add_rule(rules, 'Working\\u2026', 'Работаю…', prop='children')
add_rule(rules, 'retry', 'повторить', prop='children')
add_rule(rules, 'Stop after', 'Остановить после', prop='children')
add_rule(rules, 'runs (blank = forever)', 'выполнений (пусто = бессрочно)', prop='children')
# needs setup ( is a slice of larger string; skip the partial, the full string is elsewhere - handle below
# 'needs setup (' + requires... -> the visible part; skip translate (constructed runtime)

# Bot Chat title (3 occurrences)
add_rule(rules, 'Bot Chat', 'Чат бота', prop='title', all_=True)

with open('/tmp/bots-overrides.json', 'w', encoding='utf-8') as f:
    json.dump(rules, f, ensure_ascii=False, indent=1)
print("total rules:", len(rules))
