#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""L3-сверка i18n: en.ts ↔ ru.ts по ПОЗИЦИЯМ (n-е вхождение ключа).
Слепая зона L2 (en/ru вне скана) — этот скрипт её закрывает. Канон 25.08.

Usage: i18n-sync-check.py [en.ts] [ru.ts]
Выводит ключи, где значение в ru.ts == en.ts (не переведено) или ключ отсутствует.
Позиционная логика обязательна: имена ключей повторяются в секциях (done ×N).
Якоря-бланки (proper names/techn) фильтровать вручную (Telegram, MCP, SSH…)."""
import re, sys

# Намеренно непереведённые / языко-независимые значения (решения Влада:
# сессии 2026-08-14 recon «16 намеренно», фильтры логов agent/errors/gateway/
# desktop/all/info/warning/error — НЕ переводим; шаблоны actionCommand/
# actionTarget; proper names платформ; URL-плейсхолдеры; '0'/'.'/DIFF/YOLO…).
# Важно: только ТОЧНЫЕ совпадения или известные языко-независимые шаблоны,
# чтобы не прятать настоящие пропуски.
NOISE_VALUES = {
    # proper names платформ/сервисов (как значения, не ключи!)
    "GitHub Issues", "Discord", "Slack", "Telegram", "Email", "GitHub comment",
    "Hermes Cloud", "Hermes Desktop", "SSH", "MCP", "YOLO", "DIFF", "URL",
    "URL…", "publisher.extension", "0", ".",
    # фильтры логов (решение Влада 14.08)
    "agent", "errors", "gateway", "desktop", "all", "info", "warning", "error",
    "debug",
}

def is_noise(v):
    """Языко-независимые значения: правильные имена/фильтры, URL, плейсхолдеры.

    ${...} — шум ТОЛЬКО если вне интерполяции нет букв (${pre} · ${post} —
    языко-независимый), а «Failed to turn ${name}…» — РЕАЛЬНЫЙ кандидат
    (английский текст с подстановкой)."""
    if v in NOISE_VALUES:
        return True
    # proper-name префиксы с переменной: «SSH: ${host}», «Hermes Cloud · ${host}»,
    # «Hermes Desktop v${version}» — переводить нечего (согласовано 28.08)
    for pref in ("SSH: ", "SSH · ", "Hermes Cloud · ", "Hermes Desktop v"):
        if v.startswith(pref):
            return True
    if v.startswith(("http://", "https://")):
        return True
    if "${" in v:
        rest = re.sub(r"\$\{[^}]*\}", "", v)
        if not re.search(r"[A-Za-zА-Яа-я]", rest):
            return True  # без букв вне подстановок — языко-независимый шаблон
    return False

def parse(path):
    text = open(path, encoding="utf-8").read()
    items = []
    # Префикс секции: ближайший предшествующий заголовок «  key: {» (2 пробела).
    # Позиционная сверка остаётся, но «title» из settings.managedUpdates больше
    # не путается с boot.failure.title (коллизия generic-ключей, 28.08).
    sections = re.compile(r"^ {0,2}([A-Za-z_][A-Za-z0-9_]*):\s*\{", re.M)
    sec_starts = [(m.start(1), m.group(1)) for m in sections.finditer(text)]
    si = 0
    # группа 4 = кавычка, 5 = значение; is_fn — en-ключ стал функцией (=>)
    # функции бывают `(args) =>` И `arg =>` (ru.ts пишет без скобок!) — оба варианта
    pat = re.compile(
        r"^(\s{4,})(['A-Za-z_][A-Za-z0-9_\.\-]*?):\s*(?:(?:\([^)]*\)|[A-Za-z_][A-Za-z0-9_]*)\s*=>\s*)?([`'\"])([\s\S]{0,500}?)\3",
        re.M)
    fn_re = re.compile(r":\s*(?:\([^)]*\)|[A-Za-z_][A-Za-z0-9_]*)\s*=>")
    for m in pat.finditer(text):
        while si < len(sec_starts) and sec_starts[si][0] < m.start():
            si += 1
        sec = sec_starts[si - 1][1] if si > 0 else "?"
        v = m.group(4)
        if "\n" in v:
            continue
        # признак «функция»: в той же строке есть `(args) =>`
        is_fn = bool(fn_re.search(text[m.start():m.end(3)]))
        items.append((f"{sec}.{m.group(2).strip(chr(39))}", v.strip(), is_fn))
    return items

def audit_ru_constants(constants_path):
    """Поле-аудит (28.08): ключи FIELD_LABELS/FIELD_DESCRIPTIONS в
    settings/constants.ts против RU_FIELD_LABELS/RU_FIELD_DESCRIPTIONS.
    Раздел Browser был невидим для L1 (вне en.ts) и L3 (не i18n-ключи);
    эта сверка закрывает зону fieldLabels — отдельный механизм (ru-constants.ts).
    Возвращает список строк-находок; пусто = всё покрыто."""
    import json, re, pathlib
    const_text = pathlib.Path(constants_path).read_text(encoding="utf-8")
    ru_const = pathlib.Path.home() / "projects/hermes-desktop-ru" / "package" / "files" / "ru-constants.ts"
    ru_text = ru_const.read_text(encoding="utf-8") if ru_const.exists() else ""
    found = []
    # FIELD_LABELS — объект, ключи вида  foo: 'Label' /  'foo.bar': 'Label'
    for src_name, obj_name, ru_obj in (
        ("LABELS", "FIELD_LABELS", "RU_FIELD_LABELS"),
        ("DESCRIPTIONS", "FIELD_DESCRIPTIONS", "RU_FIELD_DESCRIPTIONS"),
    ):
        m = re.search(rf"export const {obj_name}[^=]*=\s*(?:defineFieldCopy\()?\s*\{{", const_text)
        rb = re.search(rf"export const {ru_obj}[^=]*=\s*\{{", ru_text)
        if not m or not rb:
            continue
        # вырезаем сбалансированный объект
        def extract(text, start):
            depth, i = 0, start
            while i < len(text):
                if text[i] == '{': depth += 1
                elif text[i] == '}':
                    depth -= 1
                    if depth == 0: return text[start:i+1]
                i += 1
            return text[start:]
        obj = extract(const_text, m.start())
        robj = extract(ru_text, rb.start())

        def flat_keys(block):
            """Плоские пути ключей: стек по отступам.
            {'voice': {'clientDirect': 'X'}} -> {'voice.clientDirect'};
            'display.personality' (квот. точечный) -> сам путь."""
            keys = set()
            stack = []  # (indent, name)
            for line in block.splitlines():
                mm = re.match(r"^(\s*)(?:['\"])?([a-zA-Z][a-zA-Z0-9_.]*)(?:['\"])?\s*:", line)
                if not mm:
                    continue
                indent = len(mm.group(1))
                name = mm.group(2)
                while stack and stack[-1][0] >= indent:
                    stack.pop()
                if '.' in name:
                    keys.add(name)  # квотированный плоский ключ
                    continue
                # вложенный: путь = префикс стека + name (стек держит только контейнеры)
                # просто добавляем «родитель + name»; потом фильтруем контейнеры
                prefix = stack[-1][1] + '.' if stack else ''
                keys.add(prefix + name)
                # решаем, что это контейнер, если следующий блок глубже — узнаем позже
                stack.append((indent, prefix + name))
            # убрать контейнеры: ключ, который является префиксом другого ключа
            containers = {k for k in keys if any(o.startswith(k + '.') for o in keys)}
            return {k for k in keys if k not in containers}

        keys = flat_keys(obj)
        rkeys = flat_keys(robj)
        # нормализация snake->camel: 'allow_private_urls' -> 'allowPrivateUrls'
        def norm(k):
            parts = k.split('.') if '.' in k else [k]
            out = [parts[0]]
            for x in parts[1:]:
                out.append('_'.join(y.capitalize() if '_' in y else y for y in x.split('_')))
            return '.'.join(out)
        keys = {norm(k) for k in keys}
        rkeys = {norm(k) for k in rkeys}
        missing = sorted(keys - rkeys)
        for k in missing:
            # отфильтровать технические имена (icon, id, type)
            if k in ("icon", "id", "type", "keys", "label", "section", "title"):
                continue
            found.append(f"{obj_name}.{k} → нет в {ru_obj} (fallback prettify = англ)")
    return found

def main():
    en_p, ru_p = sys.argv[1:3] if len(sys.argv) > 2 else ("/tmp/audit2/en.ts", "/tmp/audit2/ru.ts")
    en = parse(en_p)
    ru = parse(ru_p)
    ru_pos = {}
    for i, (k, v, is_fn) in enumerate(ru):
        ru_pos.setdefault(k, []).append((i, v, is_fn))
    counters = {}
    mis = []
    type_mismatch = []
    for i, (k, v, en_fn) in enumerate(en):
        n = counters.get(k, 0)
        counters[k] = n + 1
        if n < len(ru_pos.get(k, [])):
            ri, rv, ru_fn = ru_pos[k][n]
            if rv == v:
                mis.append((k, v, i + 1, ri + 1))
            # тип: en-функция vs ru-строка — краш-класс v3.5 (defineLocale merge
            # затирает EN-функции строкой) и наоборот
            if en_fn != ru_fn:
                type_mismatch.append((k, v, i + 1, ri + 1, en_fn, ru_fn))
        else:
            mis.append((k, v, i + 1, None))
    real = [m for m in mis if not is_noise(m[1])]
    noise = [m for m in mis if is_noise(m[1])]
    print(f"i18n: непереведённых/отсутствующих = {len(mis)} (реальных {len(real)}, шума {len(noise)}; en={len(en)}, ru={len(ru)})")
    for k, v, ei, ri in mis:
        print(f"  {k} | en#{ei} | ru#{'нет' if ri is None else ri} | {v[:90]}")
    if type_mismatch:
        print(f"\ni18n TYPE-MISMATCH (en↔ru функция/строка — краш-риск): {len(type_mismatch)}")
        for k, v, ei, ri, ef, rf in type_mismatch:
            kind = "en=функция, ru=строка" if ef else "en=строка, ru=функция"
            print(f"  {k} | en#{ei} | {kind} | {v[:90]}")
    # поле-аудит: constants.ts путь — аргумент №3 (опционально)
    if len(sys.argv) > 3:
        fl = audit_ru_constants(sys.argv[3])
        if fl:
            print(f"\nfieldLabels: {len(fl)} непокрытых ключей (constants.ts → RU_FIELD_*):")
            for line in fl:
                print(f"  {line}")
        else:
            print("\nfieldLabels: всё покрыто (constants.ts → RU_FIELD_*)")

if __name__ == "__main__":
    main()