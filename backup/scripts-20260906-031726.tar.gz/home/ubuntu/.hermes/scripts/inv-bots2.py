#!/usr/bin/env python3
"""Honest coverage: every UI-visible string literal -> is there a rule whose
before-block contains EXACTLY that full source line? (byte compare)."""
import json, re

SRC = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
REG = '/home/ubuntu/projects/hermes-desktop-ru/package/registry.json'

src_lines = open(SRC, encoding='utf-8').read().split('\n')
rules = json.load(open(REG))
bot = [r for r in rules if 'hermes-bots' in r.get('file', '')]

# exact full lines covered by bot rules
covered_lines = set()
for r in bot:
    if len(r['before']) == 1:
        covered_lines.add(r['before'][0])

VIS = re.compile(r'\b(children|label|title|placeholder|description|text|hint|empty(?:Text)?|header(?:Text)?|caption|tooltip|aria-label)\b')
SCALAR = re.compile(r"'((?:[^'\\]|\\.)*?)'")

untr = []
for i, ln in enumerate(src_lines, 1):
    if ln in covered_lines:
        continue
    m = VIS.search(ln)
    if not m:
        continue
    # find scalar literal attached to the visible prop (within 60 chars)
    for mm in SCALAR.finditer(ln[m.end():m.end()+70]):
        v = mm.group(1)
        if not v:
            continue
        untr.append((i, v, ln.strip()[:120]))
        break

# dedup by (value) keep first line as example
seen = {}
for i, v, s in untr:
    if v not in seen:
        seen[v] = (i, s)
print(f"непокрытых скалярных строк: {len(seen)}")
for v, (i, s) in sorted(seen.items(), key=lambda x: x[1][0]):
    print(f"{i}: {v!r}  << {s}")
