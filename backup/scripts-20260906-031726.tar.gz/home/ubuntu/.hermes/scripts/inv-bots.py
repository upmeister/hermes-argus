#!/usr/bin/env python3
"""Full inventory of string literals in hermes-bots/plugin.js.
Categories every '...' and `...` literal; flags those that look UI-visible
(prop ctx: children/label/title/placeholder/description/text/hint/empty/caption).
Prints: already-translated (covered by bot rules) vs UNTRANSLATED candidates."""
import json, re, sys

SRC = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
REG = '/home/ubuntu/projects/hermes-desktop-ru/package/registry.json'

src = open(SRC, encoding='utf-8').read()
lines = src.split('\n')

rules = json.load(open(REG))
bot = [r for r in rules if 'hermes-bots' in r.get('file', '')]
covered = set()
for r in bot:
    for b in r['before']:
        for m in re.finditer(r"'([^'\\]*(?:\\.[^'\\]*)*)'", b):
            covered.add(m.group(1))
        for m in re.finditer(r"`([^`\\]*(?:\\.[^`\\]*)*)`", b):
            covered.add(m.group(1))

SCALAR = re.compile(r"'((?:[^'\\]|\\.)*?)'")
TPL = re.compile(r"`((?:[^`\\]|\\.)*?)`")
VIS = re.compile(r'\b(children|label|title|placeholder|description|text|hint|empty(?:Text)?|header(?:Text)?|caption|tooltip|aria-label)\b')

def clean(s):
    return s

untr = []   # (line_no, kind, value, snippet)
ttl = []    # template literals
cnt = 0
for i, ln in enumerate(lines, 1):
    for m in VIS.finditer(ln):
        ctx = m.group(1)
        seg = ln[m.end():]
        # scalar single-quote right after ctx
        sm = SCALAR.match(seg.lstrip()[0:0] + seg.lstrip())
        # simpler: check for '...' or `...` within ~40 chars after ctx
        ahead = seg[:60]
        for kind, pat in (('scalar', SCALAR), ('tpl', TPL)):
            mm = pat.search(ahead)
            if mm:
                v = mm.group(1)
                if not v or v in ('', ' '):
                    continue
                cnt += 1
                if kind == 'tpl':
                    ttl.append((i, v, ln.strip()[:120]))
                elif v not in covered:
                    untr.append((i, v, ln.strip()[:130]))
                break

# dedupe, but keep line numbers
seen = set()
u = []
for i, v, s in untr:
    if v not in seen:
        seen.add(v)
        u.append((i, v, s))
seen_t = set()
ttl2 = []
for i, v, s in ttl:
    if v not in seen_t and len(ttl2) < 120:
        seen_t.add(v)
        ttl2.append((i, v, s))

print(f"всего видимых литералов: {cnt}")
print(f"непереведённых скалярных (по реестру): {len(u)}")
print("\n=== UNTRANSLATED scalar (line, value, snippet) ===")
for i, v, s in u:
    print(f"{i}: {v!r}   << {s}")
print("\n=== TEMPLATE LITERALS (первая порция) ===")
for i, v, s in ttl2:
    print(f"{i}: `{v}`   << {s}")
