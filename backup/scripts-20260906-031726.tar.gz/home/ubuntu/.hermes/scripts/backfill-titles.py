#!/usr/bin/env python3
"""Backfill auto-titles for untitled sessions (after title model fix).

For every session without a title that has >=1 user message, generate a title
from the first user->assistant exchange and persist via set_auto_title_if_empty.
"""
import sqlite3, time, sys, os

sys.path.insert(0, os.path.expanduser('~/.hermes/hermes-agent'))
from agent.title_generator import generate_title

DB = os.path.expanduser('~/.hermes/state.db')
DRY = '--dry' in sys.argv

c = sqlite3.connect(DB)
c.row_factory = sqlite3.Row

rows = c.execute("""
    SELECT s.id, s.source, s.message_count
    FROM sessions s
    WHERE (s.title IS NULL OR s.title = '' OR s.title_source = 'derived')
      AND s.message_count > 0
      AND s.source IN ('telegram','desktop')
    ORDER BY s.started_at
""").fetchall()
print(f'сессий без тайтла: {len(rows)}')

ok = fail = skip = 0
for r in rows:
    sid = r['id']
    # first user message + first assistant message after it
    first_user = c.execute(
        "SELECT content FROM messages WHERE session_id=? AND role='user' AND content!='' ORDER BY id LIMIT 1", (sid,)).fetchone()
    if not first_user:
        skip += 1; continue
    first_asst = c.execute(
        "SELECT content FROM messages WHERE session_id=? AND role='assistant' AND content!='' ORDER BY id LIMIT 1", (sid,)).fetchone()
    um = first_user['content'][:500]
    am = (first_asst['content'][:500] if first_asst else '')
    if DRY:
        print(f'  [dry] {sid} ({r["source"]}) user={um[:50]!r}')
        continue
    try:
        title = generate_title(um, timeout=60)
    except Exception as e:
        print(f'  FAIL {sid}: {e}')
        fail += 1; continue
    if not title:
        print(f'  SKIP {sid}: пустой тайтл')
        skip += 1; continue
    cur = c.execute(
        "UPDATE sessions SET title=?, title_source='llm' WHERE id=? AND (title_source IS NULL OR title_source='derived')",
        (title, sid))
    if cur.rowcount:
        print(f'  OK   {sid} ({r["source"]}): {title!r}')
        ok += 1
    else:
        print(f'  SKIP {sid}: уже есть тайтл')
        skip += 1
    c.commit()
    time.sleep(1.5)  # не долбить API

print(f'\nИтого: ok={ok} fail={fail} skip={skip}')
