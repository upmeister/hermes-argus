#!/bin/bash
systemctl --user restart hermes-dashboard hermes-gateway 2>&1
echo "Both services restarted"
