#!/bin/bash
systemctl --user restart hermes-gateway 2>&1
echo "Gateway restart triggered"
