#!/usr/bin/env python3
"""Wave w5: New Agent / Edit Profile / cron field labels + help texts in plugin.js.
Covers: Name, Title, Description, Advanced, Provider, Model, Instruction,
When to run, SOUL.md label/placeholder, Subscriptions help."""
import json, re

SRC = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
lines = open(SRC, encoding='utf-8').read().split('\n')

# map lineno -> [(exact fragment old, new)] — fragment search within the full line
SPEC = [
    (5614, "          'Provider',", "          'Провайдер',"),      # fallback grid: Provider
    (5622, "          'Model',", "          'Модель',"),
    (5678, "        'Provider',", "        'Провайдер',"),          # Edit Profile: Provider
    (5717, "        'Model',", "        'Модель',"),
    (6536, "              'Title',", "              'Заголовок',"), # Edit Profile: Title
    (6544, "              'Description',", "              'Описание',"),
    (6559, "          'Advanced — model, skills, toolsets, SOUL.md'",
           "          'Дополнительно — модель, навыки, наборы инструментов, SOUL.md'"),
    (6975, "              'Name',", "              'Имя',"),        # New Agent: Name (dup w/ cron)
    (7040, "              'Title',", "              'Заголовок',"), # New Agent: Title (dup)
    (7048, "              'Description',", "              'Описание',"),  # New Agent: Description (dup)
    (7070, "                'Advanced'", "                'Дополнительно'"),   # Advanced disclosure (no comma)
    (7174, "                              'SOUL.md (optional — replaces the generated persona)'",
           "                              'SOUL.md (необязательно — заменяет сгенерированную персону)'"),
    (7178, "                                  'Leave blank to auto-generate from name/title/description + agent-messaging roster.'",
           "                                  'Оставьте пустым, чтобы сгенерировать из имени/заголовка/описания + перечня агентов.'"),
    (8006, "              'Name',", "              'Имя',"),        # cron: Name (same as 6975)
    (8015, "              'Instruction',", "              'Инструкция',"),
    (8023, "labeled('When to run', jsx(SchedulePicker, { state: sched, setState: setSched }))",
           "labeled('Когда запускать', jsx(SchedulePicker, { state: sched, setState: setSched }))"),
]

# also find the Subscriptions help + share-auth checkbox + cron placeholders
EXTRA = [
    "Subscriptions, OAuth logins, and API keys stay shared (not copied), so token refreshes never invalidate each other. Uncheck for an isolated snapshot copy.",
    "Share keys & accounts with the main profile",
    "What should this agent help with?",
    "What should this Bot help with?",
    "What should this cronjob do each time it runs?",
]

for e in EXTRA:
    hits = [i+1 for i,l in enumerate(lines) if e in l]
    print(f"EXTRA {e[:50]!r}: {hits}")

rules = []
errors = []
for lineno, old, new in SPEC:
    ln = lines[lineno - 1]
    if old not in ln:
        errors.append(f"L{lineno}: NOT FOUND {old!r}")
        continue
    ln2 = ln.replace(old, new)
    if ln2 == ln:
        errors.append(f"L{lineno}: no change")
        continue
    occurs = [i+1 for i,l in enumerate(lines) if l == ln]
    is_all = len(occurs) > 1
    rules.append({"id": f"hermes-bots-w5-{lineno}" + ("-all" if is_all else ""),
                  "file": "apps/desktop/src/plugins/hermes-bots/plugin.js",
                  "before": [ln], "after": [ln2], **({"all": True} if is_all else {})})

print(f"\nправил: {len(rules)}  all-дублей: {sum(1 for r in rules if r.get('all'))}")
for e in errors: print(" -", e)
json.dump(rules, open('/tmp/bots-w5.json','w'), ensure_ascii=False, indent=2)
print("saved -> /tmp/bots-w5.json")
