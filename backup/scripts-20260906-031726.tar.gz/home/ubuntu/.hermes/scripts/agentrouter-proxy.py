#!/usr/bin/env python3
"""agentrouter-proxy: local reverse proxy for AgentRouter (agentrouter.org).

Why: AgentRouter runs a WAF that only accepts traffic matching official
client fingerprints (Claude Code / Codex CLI), and its SSE streams emit a
bare `data: null` line that crashes the openai-python SDK
("'NoneType' object has no attribute 'choices'").

This proxy:
  1. injects the Codex CLI fingerprint headers (WAF allowlist),
  2. strips bare `data: null` lines from SSE streams,
  3. forces Accept-Encoding: identity so streams stay uncompressed,
  4. routes egress through SOCKS5 (DE VLESS, port 1086) — Aliyun WAF
     blocks our AWS eu-north-1 egress (verified 2026-09-05).

Stdlib + python-socks (apt: python3-python-socks). Point Hermes at http://127.0.0.1:8319/v1
"""
import json
import os
import socket
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request

from python_socks.sync import Proxy as SocksProxy  # python3-python-socks (apt)

UPSTREAM = os.environ.get("AGENTROUTER_UPSTREAM", "https://agentrouter.org")
PORT = int(os.environ.get("AGENTROUTER_PROXY_PORT", "8319"))
KEY = os.environ.get("AGENTROUTER_API_KEY", "")
SOCKS_HOST = os.environ.get("AGENTROUTER_SOCKS_HOST", "127.0.0.1")
SOCKS_PORT = int(os.environ.get("AGENTROUTER_SOCKS_PORT", "1086"))

# Codex CLI fingerprint accepted by the AgentRouter WAF (verified 2026-08-07)
SPOOF_HEADERS = {
    "Originator": "codex_cli_rs",
    "Version": "0.101.0",
    "User-Agent": "codex_cli_rs/0.101.0 (Mac OS 26.0.1; arm64) Apple_Terminal/464",
}


def _socks_open(req):
    """Open the upstream HTTPS connection through the SOCKS5 proxy and
    send the request, returning the raw `http.client` response object."""
    import http.client
    from urllib.parse import urlparse
    p = urlparse(req.full_url)
    host = p.hostname
    port = p.port or 443
    path = p.path or "/"
    if p.query:
        path = f"{path}?{p.query}"

    proxy = SocksProxy.from_url(f"socks5://{SOCKS_HOST}:{SOCKS_PORT}")
    sock = proxy.connect(host, port)
    ctx = __import__("ssl").create_default_context()
    conn = http.client.HTTPSConnection(host, port, timeout=300)
    conn.sock = ctx.wrap_socket(sock, server_hostname=host)
    headers = dict(req.header_items())
    conn.request(req.get_method(), path, body=req.data, headers=headers)
    return conn.getresponse(), conn


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):  # keep the console quiet
        pass

    # ---- request handling -------------------------------------------------
    def do_GET(self):
        self._forward()

    def do_POST(self):
        self._forward()

    def _forward(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else b""
        is_stream = b'"stream": true' in body or b'"stream":true' in body

        # Build upstream request: pass client headers through minus hop-by-hop,
        # then apply our spoofed fingerprint (ours win).
        headers = {
            k: v
            for k, v in self.headers.items()
            if k.lower()
            not in ("host", "connection", "content-length", "transfer-encoding", "accept-encoding")
        }
        headers.update(SPOOF_HEADERS)
        headers["Authorization"] = f"Bearer {KEY}"
        headers["Accept-Encoding"] = "identity"

        req = Request(UPSTREAM + self.path, data=body or None, headers=headers, method=self.command)
        try:
            resp, _conn = _socks_open(req)
        except HTTPError as e:
            resp = e  # pass through 4xx/5xx bodies verbatim
            _conn = None

        # Compact request log + upstream status (diagnostics: did the request
        # actually reach AgentRouter?).
        try:
            with open(os.path.expanduser("~/.hermes/logs/agentrouter-proxy.log"), "a", encoding="utf-8") as fh:
                fh.write(f"{self.command} {self.path} -> upstream {resp.status} (body {len(body)}B)\n")
        except Exception:
            pass

        # On 4xx/5xx, record the upstream error body (may reveal WAF/quota issues).
        if resp.status >= 400:
            try:
                err_body = resp.read(2048).decode("utf-8", errors="replace")
                with open(os.path.expanduser("~/.hermes/logs/agentrouter-proxy.log"), "a", encoding="utf-8") as fh:
                    fh.write(f"  upstream error body: {err_body}\n")
                resp = None  # consumed; re-issue below
            except Exception:
                pass
        if resp is None:
            try:
                resp, _conn = _socks_open(req)
            except HTTPError as e:
                resp = e
                _conn = None

        self.send_response(resp.status)
        for k, v in resp.headers.items():
            if k.lower() in ("transfer-encoding", "connection", "content-encoding", "content-length"):
                continue
            self.send_header(k, v)
        self.send_header("Connection", "close")
        self.end_headers()

        ctype = resp.headers.get("Content-Type", "")
        if is_stream and "text/event-stream" in ctype:
            self._stream_filtered(resp)
        else:
            self._passthrough(resp)

    # ---- response paths ---------------------------------------------------
    def _passthrough(self, resp):
        while True:
            chunk = resp.read(65536)
            if not chunk:
                break
            self.wfile.write(chunk)
        self.wfile.flush()

    def _stream_filtered(self, resp):
        """Forward SSE, dropping `data: null` lines; guarantee a terminal
        `data: [DONE]` so openai-style SDK iterators terminate even when the
        upstream stream ends without a [DONE] sentinel (agentrouter quirk)."""
        buf = b""
        saw_done = False
        while True:
            chunk = resp.read(65536)
            if not chunk:
                break
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                if self._drop_line(line):
                    continue
                if line.strip() == b"data: [DONE]":
                    saw_done = True
                self.wfile.write(line + b"\n")
                self.wfile.flush()
        if buf and not self._drop_line(buf):
            if buf.strip() == b"data: [DONE]":
                saw_done = True
            self.wfile.write(buf)
            self.wfile.flush()
        if not saw_done:
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()

    @staticmethod
    def _drop_line(line: bytes) -> bool:
        if not line.startswith(b"data:"):
            return False
        payload = line[5:].strip()
        if payload == b"null":
            return True
        try:
            return json.loads(payload) is None
        except Exception:
            return False


def _load_key_from_env_file():
    """Fallback: read AGENTROUTER_API_KEY from ~/.hermes/.env if not set."""
    if KEY:
        return KEY
    env_path = os.path.expanduser("~/.hermes/.env")
    try:
        with open(env_path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line.startswith("AGENTROUTER_API_KEY="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
    except OSError:
        pass
    return ""


def main():
    global KEY
    KEY = _load_key_from_env_file()
    if not KEY:
        print("AGENTROUTER_API_KEY not found (env or ~/.hermes/.env)", file=sys.stderr)
        sys.exit(1)
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"agentrouter-proxy listening on http://127.0.0.1:{PORT} -> {UPSTREAM}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
