#!/usr/bin/env python3
"""Generate combined rule set:
  - Terminology: rename previous w3 entries (Cronjobs -> cron-задачи, Новая задача -> Новая cron-задача)
  - Panel 'New Agent' (advanced) — 14 strings
  - Panel 'New Cronjob' (from bots menu) — 2 strings + Continuity help + recurring description
  - Capabilities/General tabs
  - filter-menu.tsx (35 rules) — wait, separate file. Compose both files."""
import json

# --- filter-menu (already prepared) ---
fm = json.load(open('/tmp/filter-menu-rules.json'))

# --- TERMINOLOGY FIX (in-place) ---
TERM_RENAMES = [
    # (old_ru_phrase, new_ru_phrase, id_marker_to_find_in_existing)
    ('Задачи по расписанию', 'cron-задачи', 'title: \'Cronjobs\','),
    ('Новая задача по расписанию', 'Новая cron-задача', 'children: \'New Cronjob\''),
]

def update_existing_rule(rule, old_ru, new_ru, marker):
    for j, after_line in enumerate(rule['after']):
        if marker in rule['before'][j] and old_ru in after_line:
            rule['after'][j] = after_line.replace(old_ru, new_ru)
            return True
    return False

# --- plugin.js panel strings ---
PL = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
lines = open(PL, encoding='utf-8').read().split('\n')

PLUGIN_RULES = [
    # === panels strings to translate ===
    (6996, [("'Create on',", "'Создать на',")]),
    (7090, [("['general', 'General']", "['general', 'Общие']")]),
    (7091, [("['capabilities', 'Capabilities']", "['capabilities', 'Возможности']")]),
    (7135, [("`Clone from profile (on ${targetLabel})`", "`Клон профиля (на ${targetLabel})`"),
            ("'Clone from profile'", "'Клон профиля'")]),
    (7171, [("placeholderModel: 'inherited from launch profile'",
             "placeholderModel: 'наследуется от запускающего профиля'")]),
    (7190, [("'Share keys & accounts with the main profile'",
             "'Делиться ключами и аккаунтами с основным профилем'")]),
    (7205, [("'Create empty (skip bundled skills)'",
             "'Создать пустого (пропустить встроенные навыки)'")]),
    (7259, [("children: '“Create empty” is checked — no bundled skills will be installed.'",
             "children: '«Создать пустого» включено — встроенные навыки не будут установлены.'")]),
    (7998, [("`A recurring task ${displayName({ name: bot }, $botMeta.get()[bot])} runs on a schedule. Runs land in its own chat history.`",
             "`Регулярная задача ${displayName({ name: bot }, $botMeta.get()[bot])} выполняется по расписанию. Прогон сохраняется в её собственную историю чата.`")]),
    (8033, [("'Continuity: each run sees the previous run\\u2019s output (dedupe, continue where it left off)'",
             "'Непрерывность: каждый прогон видит результат предыдущего (дедупликация, продолжение с места остановки)'")]),
    # === 'Advanced…' tab label (in dialog) ===
    (7728, [("label: 'Advanced\\u2026'", "label: 'Дополнительно\\u2026'")]),
]

# build plugin rules
plugin_rules = []
errors = []
for lineno, frags in PLUGIN_RULES:
    ln = lines[lineno - 1]
    new = ln
    for old, repl in frags:
        if old not in new:
            errors.append(f"L{lineno}: NOT FOUND {old!r}")
            continue
        new = new.replace(old, repl)
    if new == ln:
        errors.append(f"L{lineno}: no change")
        continue
    occurs = [i + 1 for i, l in enumerate(lines) if l == ln]
    if len(occurs) > 1:
        errors.append(f"L{lineno}: not unique ({occurs})")
        continue
    plugin_rules.append({"id": f"hermes-bots-w4-{lineno}",
                         "file": "apps/desktop/src/plugins/hermes-bots/plugin.js",
                         "before": [ln], "after": [new]})

print(f"plugin.js rules: {len(plugin_rules)}")
for e in errors: print(" -", e)
print(f"filter-menu rules: {len(fm)}")
all_new = plugin_rules + fm
print(f"total new: {len(all_new)}")

# apply terminology fix in existing overrides
ov_path = '/home/ubuntu/projects/hermes-desktop-ru/package/overrides.json'
ov = json.load(open(ov_path))
fixed = 0
for old_ru, new_ru, marker in TERM_RENAMES:
    for r in ov:
        if marker in ' | '.join(r['before']):
            if update_existing_rule(r, old_ru, new_ru, marker):
                fixed += 1
print(f"terminology fixes applied to existing rules: {fixed}")

# merge
seen_before = {tuple(r['before']) for r in ov}
merged = list(ov)
dups = 0
for r in all_new:
    key = tuple(r['before'])
    if key in seen_before:
        dups += 1
        continue
    seen_before.add(key)
    merged.append(r)

print(f"old={len(ov)} new={len(all_new)} merged={len(merged)} dup-before={dups}")

# Save both: merged overrides, and just plugin-w4 for transparency
json.dump(merged, open(ov_path, 'w'), ensure_ascii=False, indent=2)
print(f"-> {ov_path}: {len(merged)} rules")
json.dump(plugin_rules, open('/tmp/bots-w4.json', 'w'), ensure_ascii=False, indent=2)