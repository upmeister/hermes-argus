#!/usr/bin/env python3
"""Weekly memory & skills health report (data collection only, no changes).

Feeds the memory-health-report cron job. Prints stable, compact facts:
memory fill %, agent-created skills >3KB, stale/archived skills.
Bundled skills are listed only as counts (they are curator off-limits).
"""
import json
import re
from pathlib import Path

HOME = Path.home() / ".hermes"


def parse_limit(cfg: Path, key: str, default: int) -> int:
    m = re.search(rf"^\s*{key}:\s*(\d+)", cfg.read_text(), re.M)
    return int(m.group(1)) if m else default


def main() -> None:
    cfg = HOME / "config.yaml"
    out = []
    for name, limit in (
        ("MEMORY.md", parse_limit(cfg, "memory_char_limit", 8800)),
        ("USER.md", parse_limit(cfg, "user_char_limit", 5500)),
    ):
        p = HOME / "memories" / name
        n = len(p.read_text()) if p.exists() else 0
        out.append(f"{name}: {n}/{limit} chars ({n * 100 // limit}%)")

    skills = HOME / "skills"
    usage = skills / ".usage.json"
    agent_created: set[str] = set()
    if usage.exists():
        try:
            data = json.loads(usage.read_text())
            agent_created = {k for k, v in data.items() if isinstance(v, dict) and v.get("created_by") == "agent"}
            stale = [k for k, v in data.items() if isinstance(v, dict) and v.get("state") == "stale"]
            archived = [k for k, v in data.items() if isinstance(v, dict) and v.get("state") == "archived"]
            out.append(f"agent-created skills: {len(agent_created)} | stale: {len(stale)} | archived: {len(archived)}")
            if stale:
                out.append("stale: " + ", ".join(sorted(stale)[:10]))
        except Exception as e:  # noqa: BLE001 - report-only script
            out.append(f".usage.json unreadable: {e}")

    big = sorted(
        (f.parent.name, f.stat().st_size // 1024)
        for f in skills.rglob("SKILL.md")
        if f.stat().st_size > 3072
    )
    out.append(f"Skills >3KB total: {len(big)} (bundled + agent)")
    agent_big = [(n, k) for n, k in big if n in agent_created]
    if agent_big:
        out.append(f"agent-created >3KB ({len(agent_big)}): " + ", ".join(f"{n} ({k}KB)" for n, k in agent_big[:15]))
    else:
        out.append("agent-created >3KB: none")

    # Fallback tier2 (17.08): curated OpenRouter free-модели живы?
    # Ротация free-списка незаметна — еженедельный канарейка в отчёте.
    try:
        import os
        import urllib.request
        key = os.environ.get("OPENROUTER_API_KEY", "")
        if key:
            req = urllib.request.Request(
                "https://openrouter.ai/api/v1/models",
                headers={"Authorization": f"Bearer {key}"},
            )
            # Без env-прокси (HTTPS_PROXY=8445 умеет только opencode.ai)
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(req, timeout=10) as resp:
                models = {m.get("id") for m in json.load(resp).get("data", [])}
            for m in ("google/gemma-4-31b-it:free", "nvidia/nemotron-3-super-120b-a12b:free"):
                out.append(
                    f"fallback {m}: {'OK' if m in models else 'GONE — обнови fallback_providers в config.yaml'}"
                )
        else:
            out.append("fallback check: OPENROUTER_API_KEY отсутствует")
    except Exception as e:  # noqa: BLE001 - report-only script
        out.append(f"fallback check: OpenRouter API недоступен ({e})")

    print("\n".join(out))


if __name__ == "__main__":
    main()
