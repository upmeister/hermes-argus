#!/usr/bin/env python3
"""Collect all string-anchor lines in hermes-bots/plugin.js that are UI-visible.
For each unique visible TEXT -> count, and sample full lines + their neighbors
(to spot concatenation fragments / risky context). No writes, analysis only."""
import re, collections, sys

path = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
lines = open(path, encoding='utf-8').read().split('\n')

# regex for scalar string props we translate
PAT = re.compile(r"^\s*(children|label|title|placeholder|alt|description|legend|aria-label|hint|providerItem|emptyStates?)\s*:\s*('(?:[^'\\]|\\.)*'|\"(?:[^\"\\]|\\.)*\"|`(?:[^`\\]|\\.)*`),?\s*(?://.*)?$")

scalar = {}  # propname+text -> list of line indexes
for i, ln in enumerate(lines):
    m = PAT.match(ln)
    if m:
        key = (m.group(1), m.group(2))
        scalar.setdefault(key, []).append(i)

print(f"scalar string props total (incl duplicates): {sum(len(v) for v in scalar.values())}")
print(f"unique (prop,text): {len(scalar)}\n")

# For each unique text, show count + a sample line + following line if looks like concatenation
seen = set()
risky = []
for (prop, text), idxs in sorted(scalar.items(), key=lambda kv: kv[0][1]):
    # decode text value
    val = text[1:-1]
    n = len(idxs)
    sample = lines[idxs[0]]
    # risk heuristic: is there a following line that starts with  +' or template? or the value has ${ }
    nxt = lines[idxs[0]+1] if idxs[0]+1 < len(lines) else ''
    concat_here = ('${' in val) or (' +' in val)
    marker = ' [CONCAT?]' if concat_here else ''
    print(f"[{n:3d}] {prop:12s} {text[:100]}{marker}")
    if marker: risky.append((prop, text, idxs[0], sample, nxt[:80]))

print(f"\n--- risky/possible-concat ({len(risky)}) ---")
for prop, text, i, s, nxt in risky:
    print(f"{prop}:{text[:80]}\n   at {i}: {s[:100]}\n   next: {nxt[:100]}\n")
