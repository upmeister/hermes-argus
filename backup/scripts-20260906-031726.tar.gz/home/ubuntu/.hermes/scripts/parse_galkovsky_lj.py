#!/usr/bin/env python3
"""Парсинг рубрикатора ЖЖ Галковского и выборочных записей для 2ch-классификатора.

Целевые темы:
- Философия, теория гегемона-субгегемона, криптоколония
- Римская империя, история Китая (фундаментальные исторические циклы)
- Новиоп, терминология
- Русская история, революция, шестидесятники
"""

import re
import json
import time
import urllib.request
import urllib.error
from html import unescape
from pathlib import Path

OUTPUT_DIR = Path("/home/ubuntu/.hermes/galkovsky-lj-corpus")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def fetch(url, retries=2):
    """Fetch URL with retries."""
    for i in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=20) as resp:
                return resp.read().decode("utf-8", errors="replace")
        except Exception as e:
            if i < retries:
                time.sleep(2)
            else:
                print(f"  [FAIL] {url}: {e}")
                return None

def strip_html(text):
    """Remove HTML tags, decode entities."""
    text = re.sub(r"<script[^>]*>.*?</script>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", text)
    text = unescape(text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

# ── Phase 1: Parse rubricator ──────────────────────────────────────────
print("=" * 70)
print("PHASE 1: Fetching rubricator from galkovsky.ru/lj/rubricator")
print("=" * 70)

rubricator_url = "https://galkovsky.ru/lj/rubricator"
rubricator_html = fetch(rubricator_url)

if not rubricator_html:
    print("FATAL: Cannot fetch rubricator")
    exit(1)

# Extract post references: "188.", "102, 177, 198." etc.
# The rubricator has format like:
#   "О философии как науке: 102, 118."
#   "Теория гегемона и субгегемона: 102, 177, 198."

# Target topics (keywords matching Galkovsky's core themes)
TARGET_TOPICS = [
    "гегемон", "субгегемон", "криптоколон", "новиоп",
    "римск", "кита", "истори",
    "философ", "революц", "шестидесят",
    "ленин", "солжениц", "розанов",
    "английск", "колониал", "русск",
    "демократ", "книгопечат", "фальсифик",
    "советск", "цивилизац", "пропаганд",
    "импер", "государств", "суверенит",
    "мат", "математ", "расизм", "аристократ",
    "личность", "политик",
]

# Parse the rubricator text
rubricator_text = strip_html(rubricator_html)

# Find all post numbers mentioned
all_numbers = re.findall(r"\b(\d{1,4})\b", rubricator_text)
print(f"Found {len(all_numbers)} number references in rubricator")

# Find lines with target topics
relevant_posts = set()
topic_map = {}  # topic -> [post numbers]

lines = rubricator_text.split(".")
for line in lines:
    line_lower = line.lower()
    for topic in TARGET_TOPICS:
        if topic in line_lower:
            nums = re.findall(r"\b(\d{1,4})\b", line)
            for n in nums:
                n_int = int(n)
                if 1 <= n_int <= 1000:  # valid ЖЖ post range
                    relevant_posts.add(n_int)
                    if topic not in topic_map:
                        topic_map[topic] = []
                    if n_int not in topic_map[topic]:
                        topic_map[topic].append(n_int)

relevant_posts = sorted(relevant_posts)
print(f"Relevant posts by topic matching: {len(relevant_posts)}")
for topic, posts in sorted(topic_map.items()):
    print(f"  {topic}: {sorted(posts)[:10]}{'...' if len(posts) > 10 else ''}")

# Save rubricator analysis
with open(OUTPUT_DIR / "rubricator_analysis.json", "w") as f:
    json.dump({
        "relevant_post_count": len(relevant_posts),
        "topic_map": {k: sorted(v) for k, v in topic_map.items()},
        "relevant_posts": relevant_posts,
    }, f, ensure_ascii=False, indent=2)

# ── Phase 2: Build priority list ───────────────────────────────────────
print("\n" + "=" * 70)
print("PHASE 2: Building priority fetch list")
print("=" * 70)

# Add specific known important posts for "Римская империя" and "История Китая"
# These are tagged in the rubricator but let's also add posts known from search
PRIORITY_EXTRA = [
    # From rubricator:
    # "Теория гегемона и субгегемона: 102, 177, 198"
    # "О философии как науке: 102, 118"
    # "О криптоколонии: 183226" (known from search)
    # "Манифест утиного движения: 696"
]

# Combine rubricator posts + hardcoded important posts
known_important = [
    # Core theory posts (from search results)
    ("183226", "О криптоколонии"),
    ("228909", "Начнем с биографии (пояснение схем)"),
    ("183449", "Манифест Утиного движения (696)"),
    # Convert to actual post numbers
]

# ЖЖ post URLs: https://galkovsky.livejournal.com/<number>.html
fetch_list = relevant_posts[:80]  # Take top 80 from rubricator
print(f"Will fetch {len(fetch_list)} posts")

# ── Phase 3: Fetch posts ───────────────────────────────────────────────
print("\n" + "=" * 70)
print("PHASE 3: Fetching ЖЖ posts")
print("=" * 70)

successful = 0
failed = 0
all_texts = []

for i, post_num in enumerate(fetch_list):
    url = f"https://galkovsky.livejournal.com/{post_num}.html"
    print(f"  [{i+1}/{len(fetch_list)}] #{post_num} ... ", end="", flush=True)
    
    html = fetch(url)
    if not html:
        failed += 1
        print("FAIL")
        continue
    
    # Extract post body
    # ЖЖ puts post text in <div class="entry-content"> or <article>
    # Try multiple patterns
    body_match = re.search(r'<div[^>]*class="[^"]*entry-content[^"]*"[^>]*>(.*?)</div>\s*<(?:div|footer)', html, re.DOTALL)
    if not body_match:
        body_match = re.search(r'<article[^>]*>(.*?)</article>', html, re.DOTALL)
    if not body_match:
        body_match = re.search(r'<div[^>]*class="[^"]*asset-body[^"]*"[^>]*>(.*?)</div>', html, re.DOTALL)
    
    if body_match:
        body_text = strip_html(body_match.group(1))
    else:
        body_text = strip_html(html)  # Fallback: whole page
    
    # Extract title
    title_match = re.search(r'<title>(.*?)</title>', html)
    title = strip_html(title_match.group(1)) if title_match else f"Post #{post_num}"
    
    # Truncate very long posts for the summary
    body_preview = body_text[:3000]
    
    all_texts.append({
        "post_num": post_num,
        "title": title,
        "text": body_text,
        "text_length": len(body_text),
    })
    
    # Save individual post
    filename = f"post_{post_num:04d}.txt"
    with open(OUTPUT_DIR / filename, "w") as f:
        f.write(f"TITLE: {title}\n")
        f.write(f"URL: {url}\n")
        f.write(f"DATE: N/A (extracted from HTML if available)\n")
        f.write(f"{'='*60}\n\n")
        f.write(body_text)
    
    successful += 1
    print(f"OK ({len(body_text)} chars)")
    
    # Be polite to the server
    time.sleep(0.5)

# ── Phase 4: Save index ────────────────────────────────────────────────
print("\n" + "=" * 70)
print(f"PHASE 4: Done! Fetched {successful}/{len(fetch_list)} posts ({failed} failed)")
print("=" * 70)

# Save full corpus index
index = {
    "total_fetched": successful,
    "total_failed": failed,
    "posts": all_texts,
}
with open(OUTPUT_DIR / "corpus_index.json", "w") as f:
    json.dump(index, f, ensure_ascii=False, indent=2)

# Print summary of what we got
print("\n--- CORPUS SUMMARY ---")
print(f"Total chars collected: {sum(p['text_length'] for p in all_texts)}")
print(f"Average post length: {sum(p['text_length'] for p in all_texts) // max(successful, 1)} chars")
print(f"\nFiles saved to: {OUTPUT_DIR}")
print("Files: rubricator_analysis.json, corpus_index.json, post_NNNN.txt")

# Print first few titles
print("\n--- SAMPLE TITLES ---")
for p in all_texts[:10]:
    print(f"  #{p['post_num']}: {p['title'][:100]}")
