#!/usr/bin/env python3
"""Add one-liner jsx rules (child strings inside jsx(...) on a single line)
to bots-overrides.json. Byte-exact from file."""
import json

path = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
lines = open(path, encoding='utf-8').read().split('\n')

VAL2RU = {
 'Edit Profile': 'Изменить профиль',
 '✏️ Enter manually…': '✏️ Ввести вручную…',
 'Upload': 'Загрузить',
 'Save': 'Сохранить',
 'Save & test': 'Сохранить и проверить',
 'Remove': 'Убрать',
 'New Group Chat': 'Новый групповой чат',
 'New Agent': 'Новый агент',
 'Manage groups': 'Управлять группами',
 'Inherit (launch profile)': 'Наследовать (профиль запуска)',
 'Group settings': 'Настройки группы',
 'Create & join': 'Создать и вступить',
 'Auto': 'Авто',
 'Activity': 'Активность',
}

rules = json.load(open('/tmp/bots-overrides.json'))

def build_rule(src_line, val, ru):
    dst = src_line.replace(f"'{val}'", f"'{ru}'")
    return {"id": f"hermes-bots-oneliner-{val[:16].replace(' ','_')}",
            "file": "apps/desktop/src/plugins/hermes-bots/plugin.js",
            "before": [src_line], "after": [dst]}

def find_line(val, prefer='children'):
    # prefer a line where prop is directly a key with no other string logic
    pat = f"{prefer}: '{val}'"
    for i, l in enumerate(lines):
        if pat in l:
            return l
    # fallback: any line containing "children: 'val'" (multi-form)
    pat2 = f"children: '{val}'"
    for l in lines:
        if pat2 in l:
            return l
    return None

for val, ru in VAL2RU.items():
    ln = find_line(val)
    if not ln:
        print("  STILL-NOTFOUND:", val)
        continue
    rules.append(build_rule(ln, val, ru))

with open('/tmp/bots-overrides.json', 'w', encoding='utf-8') as f:
    json.dump(rules, f, ensure_ascii=False, indent=1)
print("total now:", len(rules))
# re-check the earlier 94 didn't vanish
un = {r['id'] for r in rules}
print("unique ids:", len(un))
