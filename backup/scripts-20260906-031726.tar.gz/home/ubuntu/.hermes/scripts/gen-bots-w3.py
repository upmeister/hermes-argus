#!/usr/bin/env python3
"""Generate wave-3 rules for hermes-bots/plugin.js from EXACT file lines.
Strategy: each rule = full unique source line -> same line with visible
strings translated (${} and \\u escapes preserved byte-for-byte)."""
import json, re, sys

SRC = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
lines = open(SRC, encoding='utf-8').read().split('\n')

# (lineno, [ (old_fragment, new_fragment), ... ])  — fragments matched inside the full line
SPEC = [
    (165, [('New message for ${label}', 'Новое сообщение для ${label}'),
           ('has new activity', 'новая активность')]),
    (830, [('(copy)', '(копия)')]),
    (1982, [("'needs setup ('", "'нужна настройка ('"),
            ("') \\u2014 restart the gateway to enable in-app setup'", "') \\u2014 перезапустите шлюз, чтобы включить настройку в приложении'")]),
    (2006, [('children: \'Cancel\'', 'children: \'Отмена\'')]),
    (2013, [("message || 'Authorizing\\u2026'", "message || 'Авторизация\\u2026'")]),
    (2028, [("isOAuth ? 'Sign in\\u2026' : 'Set up\\u2026'", "isOAuth ? 'Войти\\u2026' : 'Настроить\\u2026'")]),
    (2329, [("tabButton('bot', 'Bot')", "tabButton('bot', 'Бот')"),
            ("tabButton('generate', 'Generate')", "tabButton('generate', 'Генерация')"),
            ("tabButton('upload', 'Upload')", "tabButton('upload', 'Загрузка')"),
            ("tabButton('pet', 'Pet')", "tabButton('pet', 'Питомец')")]),
    (2363, [("'Auto — the name decides'", "'Авто — имя решает'")]),
    (2392, [("), 'Randomize']", "), 'Случайный']")]),
    (2404, [("'Unlock' : 'Lock face'", "'Снять блокировку' : 'Зафиксировать лицо'")]),
    (2411, [("'Face locked — renaming won\\u2019t change it.'", "'Лицо зафиксировано — переименование его не изменит.'"),
            ("'Face follows the name.'", "'Лицо соответствует имени.'")]),
    (2529, [("), 'Choose an image…']", "), 'Выбрать изображение…']")]),
    (2683, [('`Search ${pets.length} pets…`', '`Питомцев: ${pets.length}…`')]),
    (2756, [('`Scroll for more (${limit} of ${ranked.length})`', '`Далее (${limit} из ${ranked.length})`')]),
    (5287, [("'No conversations yet — say hi'", "'Разговоров пока нет — поздоровайтесь'")]),
    (5434, [('`Lives on ${bot.connectionLabel}`', '`Живёт на ${bot.connectionLabel}`')]),
    (5449, [("'Working on a task right now'", "'Выполняет задачу прямо сейчас'"),
            ("'Active in the last 90s'", "'Активен последние 90 сек'")]),
    (5473, [('`Last message came from @${fromBot} (bot-to-bot)`', '`Последнее сообщение от @${fromBot} (бот-к-боту)`')]),
    (5506, [("'Unpin' : 'Pin to top'", "'Открепить' : 'Закрепить сверху'")]),
    (5526, [("'Unhide Bot' : 'Hide Bot'", "'Показать бота' : 'Скрыть бота'")]),
    (5533, [('`Groups: ${groups.join(\', \')}…`', '`Группы: ${groups.join(\', \')}…`'),
            ("'Manage groups…'", "'Управление группами…'")]),
    (6017, [("'catalog · installed' : 'catalog'", "'каталог · установлено' : 'каталог'")]),
    (6185, [("'hide the hub browser' : 'browse the full hub ▾'", "'скрыть обозреватель хаба' : 'весь хаб ▾'")]),
    (6256, [("'Searching…' : 'Search'", "'Идёт поиск…' : 'Поиск'")]),
    (6263, [("'Searching community + well-known sources — can take ~10s…'", "'Поиск по сообществу и известным источникам — может занять ~10 сек…'")]),
    (6515, [("children: 'Edit Profile'", "children: 'Редактировать профиль'")]),
    (6573, [("'Saving…' : 'Save'", "'Сохранение…' : 'Сохранить'")]),
    (6996, [("'Create on',", "'Создать на',")]),
    (7266, [("placeholder: 'Filter skills…'", "placeholder: 'Фильтр навыков…'")]),
    (7320, [("'No MCP servers configured or in the catalog.'", "'Нет настроенных серверов MCP или в каталоге.'")]),
    (7429, [("'Creating…' : 'Create Agent'", "'Создание…' : 'Создать агента'")]),
    (7728, [("label: 'Advanced\\u2026'", "label: 'Дополнительно\\u2026'")]),
    (7996, [("children: 'New Cronjob'", "children: 'Новая задача по расписанию'")]),
    (8058, [("'Scheduling…' : 'Create Cronjob'", "'Сохранение…' : 'Создать задачу'")]),
    (8206, [("'Create a cronjob for this bot' : 'Create Cronjob'", "'Создать задачу по расписанию для этого бота' : 'Создать задачу'")]),
    (8263, [('`Open ${label}\'s chat`', '`Открыть чат ${label}`')]),
    (8364, [("'New group…' : 'Group name (e.g. Research)'", "'Новая группа…' : 'Имя группы (напр. «Исследование»)'")]),
    (8457, [("'Generating…' : 'Generate'", "'Генерация…' : 'Сгенерировать'")]),
    (8727, [('`No bots match “${query.trim()}”`', '`Нет ботов по запросу «${query.trim()}»`'),
            ("'No bots yet — create agents first.'", "'Пока нет ботов — сначала создайте агентов.'")]),
    (8760, [("'Pick at least 2 bots'", "'Выберите минимум 2 ботов'")]),
    (9112, [("'Or type your own answer…' : 'Type your answer…'", "'Или введите свой ответ…' : 'Введите ответ…'")]),
    (9136, [("'Sending…' : isApproval ? 'Respond' : 'Answer'", "'Отправка…' : isApproval ? 'Ответить' : 'Ответ'")]),
    (9248, [('`${group} — group chat`', '`${group} — групповой чат`')]),
    (9268, [('`${members.length} bots`', '`${members.length} ботов`')]),
    (9274, [('`Group settings — rename ${group} or set a room picture`', '`Настройки группы — переименуйте ${group} или задайте обложку`')]),
    (9282, [('`Disband the ${group} group chat`', '`Расформировать чат группы ${group}`')]),
    (9307, [("'Hide room activity' : 'Show room activity'", "'Скрыть активность комнаты' : 'Показать активность комнаты'")]),
    (9515, [("'Hide full handle' : 'Show full handle'", "'Скрыть полный хендл' : 'Показать полный хендл'")]),
    (9556, [("'attached file'", "'вложенный файл'")]),
    (9565, [("'attached image'", "'вложенное изображение'")]),
    (9624, [("children: headText || 'Thread'", "children: headText || 'Тред'")]),
    (9648, [("), 'Collapse thread']", "), 'Свернуть тред']")]),
    (9675, [("'Reply in thread…'", "'Ответить в треде…'")]),
    (9730, [("'Drop to attach to this thread reply' : 'Drop to attach — every responding bot sees it'",
             "'Перетащите, чтобы прикрепить к ответу в треде' : 'Перетащите для прикрепления — увидят все отвечающие боты'")]),
    (10181, [("'Activity toasts on — click to silence' : 'Activity toasts off — click to enable'",
              "'Уведомления об активности включены — нажмите, чтобы заглушить' : 'Уведомления об активности выключены — нажмите, чтобы включить'")]),
    (10200, [("'Hide hidden bots' : 'Show hidden bots'", "'Скрыть скрытых ботов' : 'Показать скрытых ботов'")]),
    (10239, [("), 'New Agent']", "), 'Новый агент']")]),
    (10244, [("), 'New Group Chat']", "), 'Новый групповой чат']")]),
    (10416, [("), 'New Agent']", "), 'Новый агент']")]),
    (10676, [("title: 'Bots',", "title: 'Боты',")]),
    (10719, [("title: 'Cronjobs',", "title: 'Задачи по расписанию',")]),
    (9778, [('`Message ${group}`', '`Сообщение для ${group}`')]),
]

rules = []
errors = []
used_ids = set()
for lineno, frags in SPEC:
    ln = lines[lineno - 1]
    new = ln
    for old, repl in frags:
        if old not in new:
            errors.append(f"L{lineno}: fragment NOT FOUND: {old!r} in {ln.strip()[:90]!r}")
            continue
        new = new.replace(old, repl)
    if new == ln:
        errors.append(f"L{lineno}: no change produced")
        continue
    # uniqueness sanity
    occurs = [i + 1 for i, l in enumerate(lines) if l == ln]
    if len(occurs) > 1:
        errors.append(f"L{lineno}: source line not unique ({len(occurs)}x) — {ln.strip()[:80]!r}")
        continue
    rid = f"hermes-bots-w3-{lineno}"
    rules.append({"id": rid, "file": "apps/desktop/src/plugins/hermes-bots/plugin.js",
                  "before": [ln], "after": [new]})
    used_ids.add(rid)

print(f"правил: {len(rules)}")
if errors:
    print("ОШИБКИ:")
    for e in errors:
        print(" -", e)
# dump
with open('/tmp/bots-w3.json', 'w', encoding='utf-8') as f:
    json.dump(rules, f, ensure_ascii=False, indent=2)
# quick preview count
print("saved -> /tmp/bots-w3.json")
