#!/usr/bin/env python3
"""L3-крон: i18n-сверка en.ts ↔ ru.ts (позиционная, по n-му вхождению ключа).

Паттерн no_agent: печатаем ТОЛЬКО когда вывод изменился с прошлого прогона
(иначе каждый день шумим 31 proper-name'ом, которые фильтруются вручную).
Состояние — ~/.hermes/scripts/upstream-watch/l3-state (sha256 вывода).

Использование: python3 i18n-sync-cron.py
"""
import hashlib, os, subprocess, sys

SCRIPT = os.path.expanduser("~/.hermes/scripts/i18n-sync-check.py")
SCRATCH = os.path.expanduser("~/.hermes/scripts/upstream-watch")
EN = os.path.join(SCRATCH, "cache", "en.ts")
if not os.path.exists(EN):
    EN = os.path.expanduser("~/projects/hermes-agent-dev/apps/desktop/src/i18n/en.ts")
# падать нельзя — i18n-sync-check сам скажет, если en отсутствует
RU = os.path.expanduser("~/projects/hermes-desktop-ru/i18n/ru.ts")
STATE = os.path.expanduser("~/.hermes/scripts/upstream-watch/l3-state")

def main() -> int:
    args = [SCRIPT, EN, RU]
    # поле-аудит: constants.ts с ПК (из upstream-кэша L1, если он там есть)
    const_candidates = [
        os.path.join(SCRATCH, "cache", "constants.ts"),
        os.path.expanduser("~/projects/hermes-agent-dev/apps/desktop/src/app/settings/constants.ts"),
    ]
    const = next((c for c in const_candidates if os.path.exists(c)), None)
    if const:
        args.append(const)
    r = subprocess.run([sys.executable, *args],
                       capture_output=True, text=True, timeout=120)
    if r.returncode != 0:
        print(f"L3: i18n-sync-check.py упал ({r.returncode}): {r.stderr[:200]}")
        return r.returncode
    out = r.stdout.strip()
    h = hashlib.sha256(out.encode("utf-8")).hexdigest()[:16]
    prev = ""
    if os.path.exists(STATE):
        prev = open(STATE, encoding="utf-8").read().strip()
    open(STATE, "w", encoding="utf-8").write(h)
    if prev == h:
        return 0  # без изменений -> тишина
    if out:
        print(out)
    return 0

if __name__ == "__main__":
    sys.exit(main())