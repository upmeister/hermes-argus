#!/usr/bin/env python3
"""Wave w6: 3 rows in plugin.js.
1) Name placeholder inbox-triage -> разбор-входящих
2) (current) -> (текущий)
3) Capabilities tab placeholder 'Name the agent first...' -> RU"""
import json

SRC = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
lines = open(SRC, encoding='utf-8').read().split('\n')

SPEC = [
    (6978, "placeholder: 'inbox-triage',", "placeholder: 'разбор-входящих',"),
    (7022, "`${connection.label || connection.id} (current)`",
           "`${connection.label || connection.id} (текущий)`"),
    (7216, "': 'Name the agent first — a draft profile is created when you open this tab (discarded if you cancel).'",
           "': 'Сначала укажите имя агента — при открытии этой вкладки создаётся черновой профиль (отбрасывается при отмене).'"),
]

rules = []
errors = []
for lineno, old, new in SPEC:
    ln = lines[lineno - 1]
    if old not in ln:
        errors.append(f"L{lineno}: NOT FOUND {old!r}")
        continue
    ln2 = ln.replace(old, new)
    if ln2 == ln:
        errors.append(f"L{lineno}: no change")
        continue
    occurs = [i+1 for i,l in enumerate(lines) if l == ln]
    if len(occurs) > 1:
        errors.append(f"L{lineno}: not unique ({occurs})")
        continue
    rules.append({"id": f"hermes-bots-w6-{lineno}",
                  "file": "apps/desktop/src/plugins/hermes-bots/plugin.js",
                  "before": [ln], "after": [ln2]})

print(f"правил: {len(rules)}")
for e in errors: print(" -", e)
# show the actual before/after for transparency
for r in rules:
    print("---", r['id'])
    print("  B:", r['before'][0].strip()[:100])
    print("  A:", r['after'][0].strip()[:100])
json.dump(rules, open('/tmp/bots-w6.json','w'), ensure_ascii=False, indent=2)
print("saved -> /tmp/bots-w6.json")
