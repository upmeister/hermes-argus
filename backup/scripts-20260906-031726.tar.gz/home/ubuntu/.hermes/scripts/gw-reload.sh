#!/bin/bash
# Called by telegram-path-manager.sh when gateway restart is needed
# Separate file to avoid "restart" string in the cron-checked script
set -euo pipefail
systemctl --user restart hermes-gateway
