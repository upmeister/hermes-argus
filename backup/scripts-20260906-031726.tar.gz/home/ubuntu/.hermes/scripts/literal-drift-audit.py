#!/usr/bin/env python3
"""Drift-аудит (level 2): полный скан UI-литералов apps/desktop (src+electron)
+ tui_gateway/server.py (бэкенд-подсказки) против покрытия мода. Тихий при
чистом результате (пустой stdout = no_agent молчит); при находках — резюме
с категориями UI (куда смотреть) в stdout (Владу), полный отчёт в
~/.hermes/logs/drift-report.txt. Запуск: cron no_agent, раз в сутки."""
import json, os, subprocess, sys, tarfile, tempfile, io

sys.path.insert(0, os.path.expanduser('~/.hermes/scripts/upstream-watch'))
from literals import extract, load_covered, uncovered

PC = "covhnw-pc2"
LOGS = os.path.expanduser("~/projects/hermes-desktop-ru/reports/drift-report.txt")
BACKLOG = os.path.expanduser("~/obsidian-vault/active-tasks/ru-mod-backlog.md")
MAX_FILES, MAX_ROWS = 15, 8

# Демо/dev-файлы апстрима (не UI пользователя). ТОЧЕЧНО, не по маске *dev*/fixture —
# simulated-api.ts (billing) — реальный UI-режим симуляции (решение Влада 26.08).
DEV_EXCLUDE = ("plugins/hello-runtime", "contrib/dev/credits-notice-demo.ts", "chat/perf-probe.tsx")

# Карта файлов -> поверхности UI (для «куда смотреть глазами» при вижн-тесте)
def categorize(rel):
    p = rel.replace("\\", "/")
    if p.startswith("apps/desktop/src/app/contrib") or "command-palette" in p or "contrib/types" in p:
        return "палитра ⌘K / меню вкладок / макеты"
    if "themes/" in p:
        return "Настройки → Внешний вид (темы/стекло)"
    if "plugins/hermes-bots" in p:
        return "вкладка Боты / групповые чаты"
    if "plugins/kanban" in p:
        return "канбан-доска / горячие клавиши"
    if p.startswith("apps/desktop/src/i18n") or "ru-constants" in p:
        return "глобальные строки / поля настроек"
    if "app/settings" in p or "settings/constants" in p:
        return "Настройки (вкладки/поля)"
    if "sdk/index" in p or "open-session" in p or "session/hooks" in p:
        return "загрузка сессий / тосты-алерты"
    if "assistant-ui" in p:
        return "сообщения ассистента / вставки"
    if p.startswith("apps/desktop/electron"):
        return "системные диалоги / предпросмотр"
    if p.startswith("tui_gateway"):
        return "серверные подсказки (голос/шлюз)"
    return "прочее"

def pull_src():
    """scp-архив src+electron+tui_gateway с ПК -> dict {relpath: text}."""
    tmp = tempfile.mkdtemp(prefix="drift-src-")
    try:
        proc = subprocess.run(
            ["ssh", PC, "cd C:/Users/covhnw/AppData/Local/hermes/hermes-agent && tar czf - apps/desktop/src apps/desktop/electron tui_gateway/server.py"],
            capture_output=True, timeout=150)
        if proc.returncode != 0:
            return None
        with tarfile.open(fileobj=io.BytesIO(proc.stdout), mode="r:gz") as t:
            t.extractall(tmp)
        out = {}
        roots = [
            (os.path.join(tmp, "apps", "desktop", "src"), "apps/desktop/src"),
            (os.path.join(tmp, "apps", "desktop", "electron"), "apps/desktop/electron"),
        ]
        for rp, prefix in roots:
            if not os.path.isdir(rp):
                continue
            for root, _, files in os.walk(rp):
                if root.replace("\\", "/").endswith("/i18n"):
                    continue  # i18n-каталог — i18n-волной, не registry
                for fn in files:
                    if not fn.endswith(('.ts', '.tsx', '.js')):
                        continue
                    if fn.endswith(('.test.ts', '.test.tsx', '.test.mjs')):
                        continue
                    p = os.path.join(root, fn)
                    rel = prefix + "/" + os.path.relpath(p, rp).replace("\\", "/")
                    if any(ex in rel for ex in DEV_EXCLUDE):
                        continue
                    try:
                        out[rel] = open(p, encoding='utf-8').read()
                    except UnicodeDecodeError:
                        pass
        tui = os.path.join(tmp, "tui_gateway", "server.py")
        if os.path.exists(tui):
            out["tui_gateway/server.py"] = open(tui, encoding='utf-8').read()
        return out
    except Exception:
        return None
    finally:
        subprocess.run(["rm", "-rf", tmp], capture_output=True)

def main():
    src = pull_src()
    if not src:
        print("DRIFT: ПК covhnw-pc2 недоступен — проверка пропущена")
        return
    covered = load_covered()
    report = {}
    for rel, text in src.items():
        unc = uncovered(extract(text, rel), covered)
        if unc:
            report[rel] = unc
    if not report:
        return  # чистый -> молчим
    total = sum(len(v) for v in report.values())
    cats = {}
    for rel in report:
        cats.setdefault(categorize(rel), []).append(rel)
    with open(LOGS, "w", encoding="utf-8") as f:
        f.write(f"DRIFT: {total} непокрытых литералов в {len(report)} файлах\n")
        for cat in sorted(cats):
            f.write(f"\n== {cat} ==\n")
            for rel in sorted(cats[cat]):
                for label, n, s in report[rel][:25]:
                    f.write(f"  {rel}:{n}: {s}\n")
    # Авто-классификация: stdout = ТОЛЬКО находки, отсутствующие в бэклоге.
    # Пусто -> no_agent молчит (всё уже учтено в ru-mod-backlog.md).
    fresh = diff_backlog(report)
    if not fresh:
        return
    fresh_by_rel = {}
    for rel, n, s in fresh:
        fresh_by_rel.setdefault(rel, []).append((n, s))
    print(f"DRIFT: {len(fresh)} НОВЫХ непокрытых литералов в {len(fresh_by_rel)} файлах (в бэклоге нет; полный отчёт: reports/drift-report.txt)")
    print("📋 Внести в бэклог — готовые кандидаты волны:")
    for rel in sorted(fresh_by_rel, key=lambda r: -len(fresh_by_rel[r]))[:MAX_FILES]:
        print(f"  [{categorize(rel)}] {rel}")
        for n, s in fresh_by_rel[rel][:MAX_ROWS]:
            print(f"    {rel}:{n}: {s}")

def diff_backlog(report):
    """Авто-классификация: литералы из отчёта, которых ещё НЕТ в ru-mod-backlog.md.
    Возвращает список новых (rel, line, s) — их надо внести в бэклог, чтобы не терять."""
    if not os.path.exists(BACKLOG):
        # бэклога нет — считаем всё новым
        return [(rel, n, s) for rel, entries in report.items() for _, n, s in entries]
    text = open(BACKLOG, encoding="utf-8").read()
    fresh = []
    for rel, entries in report.items():
        for label, n, s in entries:
            # короткий токен — точный кавычечный матч (тот же баг, что 'Up' ⊂ 'Updates')
            if len(s) <= 4:
                q = any(f"'{s}'" in text or f'"{s}"' in text or f"`{s}`" in text for _ in [0])
                if not q:
                    fresh.append((rel, n, s))
            elif s not in text:
                fresh.append((rel, n, s))
    return fresh

if __name__ == "__main__":
    main()