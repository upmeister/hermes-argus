#!/bin/bash
# telegram-path-manager.sh — autonomous Telegram path failover
# Каскад: direct (eth0) → WARP (wg0→wg1→wg2, ip rule → table 99) → VLESS (sing-box socks) → Tor
# Все проверки живучести — END-TO-END (полный HTTP-запрос с ответом api.telegram.org),
# т.к. РКН-полублок: TCP-коннект может проходить, а ответы не приходить.
# Gateway и потребители ходят через telegram-smart-proxy (8444, permanent):
# vless-тир для трафика живёт ВНУТРИ smart-proxy (direct → vless → tor),
# здесь — пробы, warp-переключатель на уровне ядра, state и алерты.
# Runs as systemd user timer (telegram-path-manager.timer), silent when stable.
#
# State: ~/.hermes/state/telegram-path-state.json
#   {"mode": "direct"|"warp"|"vless"|"tor"|"blocked", "detail": "<wgX|ee|de|uk|auto>", "since": "<iso8601>", "notified": true}

set -euo pipefail

ENV_FILE="$HOME/.hermes/.env"
STATE_FILE="$HOME/.hermes/state/telegram-path-state.json"
[ -f "$ENV_FILE" ] && set -a && source "$ENV_FILE" && set +a

MONITORING_BOT_TOKEN="${WATCHDOG_BOT_TOKEN:-}"
MONITORING_CHAT_ID="${WATCHDOG_CHAT_ID:-1045123228}"
TELEGRAM_ENDPOINT="https://api.telegram.org"

# Direct IPs to test (must include at least one from each /22 subnet)
DIRECT_IPS=(
  149.154.167.220    # DC2 Amsterdam
  149.154.166.110    # DC2 Amsterdam
  149.154.175.53     # DC1 Miami
  91.108.56.130      # DC5 Singapore
)

# WARP interfaces, tried in order (all Table=off, DNS-строк нет — wg-quick безопасен)
WARP_IFACES=(wg0 wg1 wg2)

# VLESS per-server socks ports (sing-box pinned inbounds) + auto (urltest-каскад).
# 25.08.2026: подписка chaykabot истекла (24.08) — nl/es/cz/uk УДАЛЕНЫ из конфига;
# остался только g0 (NekoVPN tcp, pinned 1086) + auto (1080). Порт 1084 — sing-box-us (US ss).
VLESS_PROBES=(1086:g0 1080:auto)

# Telegram subnets routed into WARP table when warp mode is active
WARP_SUBNETS=(
  "149.154.160.0/20:4500"
  "91.108.56.0/22:4501"
)

# Tor SOCKS5 (fallback path, managed by telegram-smart-proxy)
TOR_PROXY="socks5://127.0.0.1:9050"
# Smart proxy (CONNECT) — preferred channel for our own alerts
SMART_PROXY="http://127.0.0.1:8444"

log() { echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*" >&2; }

send_telegram() {
  local text="$1"
  [ -z "$MONITORING_BOT_TOKEN" ] && { log "WARN: no WATCHDOG_BOT_TOKEN"; return 1; }
  local proxy_args=()
  # Алерты шлём через smart-proxy, если он жив (переживает tor/warp-режимы)
  if (exec 3<>/dev/tcp/127.0.0.1/8444) 2>/dev/null; then
    exec 3>&- 3<&-
    proxy_args=(--proxy "$SMART_PROXY")
  fi
  curl -s "${proxy_args[@]}" --connect-timeout 10 --max-time 15 \
    -X POST "https://api.telegram.org/bot${MONITORING_BOT_TOKEN}/sendMessage" \
    -d "chat_id=${MONITORING_CHAT_ID}" \
    --data-urlencode "text=$text" \
    -d "disable_notification=true" \
    -o /dev/null 2>/dev/null || true
}

# Test direct path: bind to eth0 so warp ip-rule can't hijack the test
direct_works() {
  for ip in "${DIRECT_IPS[@]}"; do
    local code
    code=$(sudo -n curl --interface ens5 -s --connect-timeout 5 --max-time 5 \
      --resolve "api.telegram.org:443:$ip" \
      -o /dev/null -w "%{http_code}" "$TELEGRAM_ENDPOINT" 2>&1) || code="000"
    if echo "$code" | grep -qE "200|301|302|404"; then
      return 0
    fi
  done
  return 1
}

# WARP cascade: for each wgX — bring up if down, then END-TO-END curl через интерфейс.
# Печать: имя рабочего интерфейса (wg0/wg1/wg2) или пусто.
warp_works() {
  for wg in "${WARP_IFACES[@]}"; do
    if ! ip link show "$wg" &>/dev/null; then
      sudo -n wg-quick up "$wg" >/dev/null 2>&1 || continue
      sleep 1
    fi
    for ip in "${DIRECT_IPS[@]:0:2}"; do
      local code
      code=$(sudo -n curl --interface "$wg" -s --connect-timeout 4 --max-time 5 \
        --resolve "api.telegram.org:443:$ip" \
        -o /dev/null -w "%{http_code}" "$TELEGRAM_ENDPOINT" 2>&1) || code="000"
      if echo "$code" | grep -qE "200|301|302|404"; then
        echo "$wg"
        return 0
      fi
    done
  done
  return 1
}

# VLESS cascade: per-server pinned ports, END-TO-END через socks (remote DNS — socks5-hostname).
# Печать: "порт:имя" рабочего сервера или пусто.
vless_works() {
  for entry in "${VLESS_PROBES[@]}"; do
    local port="${entry%%:*}" name="${entry##*:}"
    local code
    code=$(curl -s --socks5-hostname "127.0.0.1:$port" --connect-timeout 5 --max-time 6 \
      -o /dev/null -w "%{http_code}" "$TELEGRAM_ENDPOINT" 2>&1) || code="000"
    if echo "$code" | grep -qE "200|301|302|404"; then
      echo "$port:$name"
      return 0
    fi
  done
  return 1
}

warp_rule_on() {
  local active_if="$1"
  for entry in "${WARP_SUBNETS[@]}"; do
    local subnet="${entry%%:*}" pref="${entry##*:}"
    if ! ip rule show | grep -q "to $subnet lookup 99"; then
      sudo -n ip rule add to "$subnet" lookup 99 pref "$pref" 2>/dev/null || true
      log "WARP rule added: $subnet → table 99"
    fi
  done
  # Единственный активный интерфейс владеет default-маршрутом таблицы 99
  sudo -n ip route replace default dev "$active_if" table 99 2>/dev/null || true
}

warp_rule_off() {
  for entry in "${WARP_SUBNETS[@]}"; do
    local subnet="${entry%%:*}" pref="${entry##*:}"
    if ip rule show | grep -q "to $subnet lookup 99"; then
      sudo -n ip rule del to "$subnet" lookup 99 pref "$pref" 2>/dev/null || true
      log "WARP rule removed: $subnet"
    fi
  done
}

tor_works() {
  local code
  code=$(curl -s --socks5 127.0.0.1:9050 --connect-timeout 10 --max-time 10 \
    -o /dev/null -w "%{http_code}" "$TELEGRAM_ENDPOINT" 2>&1) || code="000"
  echo "$code" | grep -qE "200|301|302|404"
}

read_state() {
  mkdir -p "$(dirname "$STATE_FILE")"
  if [ -f "$STATE_FILE" ]; then
    python3 -c "import json; d=json.load(open('$STATE_FILE')); print(d.get('mode','direct'))" 2>/dev/null || echo "direct"
  else
    echo "direct"
  fi
}

state_get() {
  python3 -c "import json; print(json.load(open('$STATE_FILE')).get('$1',''))" 2>/dev/null || echo ""
}

write_state() {
  local mode="$1" detail="$2" streak="${3:-0}" last_alert="${4:-0}" since="${5:-}"
  # since = время ПОСЛЕДНЕГО ПЕРЕХОДА режима. При обычных тиках сохраняем прежнее
  # значение, иначе напоминание «всё ещё blocked (N мин)» никогда не сработает.
  if [ -z "$since" ]; then
    since=$(state_get since)
    [ -z "$since" ] && since="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  fi
  mkdir -p "$(dirname "$STATE_FILE")"
  echo "{\"mode\":\"$mode\",\"detail\":\"$detail\",\"since\":\"$since\",\"notified\":true,\"streak\":$streak,\"last_alert\":$last_alert}" > "$STATE_FILE"
}

# ── Main ────────────────────────────────────────────────────────────────

CURRENT_MODE=$(read_state)
BEST_MODE="$CURRENT_MODE"
DETAIL=""
ALERT_MSG=""

if direct_works; then
  BEST_MODE="direct"
elif WARP_IF=$(warp_works) && [ -n "$WARP_IF" ]; then
  BEST_MODE="warp"
  DETAIL="$WARP_IF"
elif VLESS_RESULT=$(vless_works) && [ -n "$VLESS_RESULT" ]; then
  BEST_MODE="vless"
  DETAIL="${VLESS_RESULT##*:}"
elif tor_works; then
  BEST_MODE="tor"
else
  BEST_MODE="blocked"
fi

STREAK=$(state_get streak)
[ -z "$STREAK" ] && STREAK=0
LAST_ALERT=$(state_get last_alert)
[ -z "$LAST_ALERT" ] && LAST_ALERT=0
NOW_EPOCH=$(date +%s)

# Hysteresis: смена режима ТОЛЬКО после 2 подряд одинаковых результатов
# (мерцающая РКН-волна: единичный провал direct не должен дёргать канал туда-обратно)
if [ "$BEST_MODE" != "$CURRENT_MODE" ]; then
  STREAK=$((STREAK + 1))
  if [ "$STREAK" -ge 2 ]; then
    # Реальный переход
    if [ "$BEST_MODE" = "warp" ]; then
      warp_rule_on "$DETAIL"
    else
      warp_rule_off
    fi
    case "$BEST_MODE" in
      direct) ALERT_MSG="✅ Telegram: прямой доступ восстановлен (был $CURRENT_MODE)";;
      warp)   ALERT_MSG="⚠️ Telegram: прямые IP заблокированы → WARP-туннель ($DETAIL)";;
      vless)  ALERT_MSG="⚠️ Telegram: direct+WARP недоступны → VLESS ($DETAIL)";;
      tor)    ALERT_MSG="⚠️ Telegram: direct+WARP+VLESS недоступны → Tor SOCKS5";;
      blocked) ALERT_MSG="🚨 Telegram: ВСЕ пути заблокированы!";;
    esac
    # Дебаунс алертов: не чаще 1/15 мин (blocked — всегда, это экстренный класс)
    if [ "$BEST_MODE" = "blocked" ] || [ $((NOW_EPOCH - LAST_ALERT)) -ge 900 ]; then
      log "State change: $CURRENT_MODE → $BEST_MODE ($ALERT_MSG)"
      send_telegram "$ALERT_MSG"
      LAST_ALERT=$NOW_EPOCH
    else
      log "State change: $CURRENT_MODE → $BEST_MODE (alert debounced)"
    fi
    STREAK=0
    write_state "$BEST_MODE" "$DETAIL" 0 "$LAST_ALERT" "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  else
    log "Hysteresis: $BEST_MODE (${DETAIL:-—}) подряд $STREAK/2 — ждём (было: $CURRENT_MODE)"
    write_state "$CURRENT_MODE" "$(state_get detail)" "$STREAK" "$LAST_ALERT"
  fi
else
  STREAK=0
  if [ "$BEST_MODE" = "blocked" ]; then
    since=$(python3 -c "import json; print(json.load(open('$STATE_FILE')).get('since','?'))" 2>/dev/null || echo "?")
    minutes_elapsed=$(( ($(date +%s) - $(date -d"$since" +%s 2>/dev/null || echo 0)) / 60 ))
    if [ "$minutes_elapsed" -gt 0 ] && [ $((minutes_elapsed % 15)) -eq 0 ]; then
      send_telegram "🚨 Telegram всё ещё недоступен (${minutes_elapsed}мин). ВСЕ пути заблокированы."
      LAST_ALERT=$NOW_EPOCH
    fi
  fi
  write_state "$CURRENT_MODE" "$DETAIL" 0 "$LAST_ALERT"
fi

log "Mode: $BEST_MODE (${DETAIL:-—}, was: $CURRENT_MODE, streak=$STREAK)"
exit 0
