#!/usr/bin/env python3
"""Incremental lesson miner for hermes-desktop-ru.

Сканирует прошлые сессии/заметки мода (Obsidian sessions/, UPSTREAM-WATCH,
CHANGELOG, бэклог) на маркеры-уроки. ПОЛНЫЙ ОТЧЁТ всегда пишется в
~/projects/hermes-desktop-ru/reports/session-lessons.md (вне git, как
drift-report.txt). stdout: только новое с прошлого прогона (для no_agent-крона
тихий при отсутствии нового).

Usage:
  python3 ru-mod-session-lessons.py          # инкремент; stdout = только новое,
                                             # полный отчёт переписан в файл
  python3 ru-mod-session-lessons.py --full   # дайджест в stdout + полный отчёт в файл
  python3 ru-mod-session-lessons.py --reset  # забыть state, переобработать всё
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

HOME = Path.home()
STATE = HOME / ".hermes" / "scripts" / "session-lessons-state.json"
REPORT = HOME / "projects" / "hermes-desktop-ru" / "reports" / "session-lessons.md"

SCAN = [
    HOME / "obsidian-vault" / "sessions",
    HOME / "projects" / "hermes-desktop-ru" / "UPSTREAM-WATCH.md",
    HOME / "projects" / "hermes-desktop-ru" / "CHANGELOG.md",
    HOME / "obsidian-vault" / "active-tasks" / "ru-mod-backlog.md",
    HOME / "obsidian-vault" / "active-tasks" / "ru-mod-promo-plan.md",
]

# Категория -> маркеры. Ищем в строках (регистронезависимо).
CATEGORIES = {
    "пропуски-вотчеров": [
        "проглядел", "слепая зона", "не увидел", "не заметил", "не поймал",
        "пропустил", "missed", "blind spot", "не был переведён", "остался на английском",
    ],
    "уроки-триажа": [
        "не переводим", "не переводить", "не трогаем", "proper name", "исключение",
        "намеренно", "noise", "ложное срабатывание", "фантом",
    ],
    "паттерны-правил": [
        "паттерн", "правило", "anchor", "якорь", "движок", "before/after",
        "все 4 вместе", "вместе", "пара", "все:true", "all: true",
    ],
    "боль-инфраструктуры": [
        "перезапуск", "OOM", "ребут", "restart", "крон молчит", "no_agent",
        "EXPECTED_COMMIT", "переснимать", "HEAD ушёл вперёд",
    ],
}


def mtime_key(p: Path) -> float:
    try:
        return p.stat().st_mtime
    except OSError:
        return 0.0


def content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def collect_files() -> list[tuple[str, str]]:
    """(label, path) для всех релевантных файлов.

    Отбираем только ru-mod/desktop-мод сессии (сетевые/инфраструктурные отдельно
    лежат в других файлах и не несут уроков для вотчеров)."""
    MOD_HINTS = ("ru-mod", "hermes-desktop", "desktop-mods", "desktop-timestamps-mod")
    out = []
    for base in SCAN:
        if base.is_dir():
            for p in sorted(base.glob("*.md")):
                if any(h in p.name.lower() for h in MOD_HINTS):
                    out.append((str(p), str(p)))
        elif base.is_file():
            out.append((base.name, str(base)))
    return out


def extract_lessons(path: str) -> list[str]:
    """Строки с маркерами, сгруппированные по категориям."""
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    found: dict[str, list[str]] = {}
    for ln, line in enumerate(text.splitlines(), 1):
        low = line.lower()
        for cat, markers in CATEGORIES.items():
            if any(m in low for m in markers):
                found.setdefault(cat, []).append(f"{ln}: {line.strip()[:220]}")
    out = []
    for cat in CATEGORIES:
        if cat in found:
            out.append(f"  [{cat}]")
            out.extend(f"    {s}" for s in found[cat][:8])
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--full", action="store_true", help="дайджест в stdout (все файлы)")
    ap.add_argument("--reset", action="store_true", help="забыть state, переобработать всё")
    args = ap.parse_args()

    state: dict[str, float] = {}
    if STATE.exists() and not args.reset:
        state = json.loads(STATE.read_text(encoding="utf-8"))

    fresh_state: dict[str, float] = {}
    fresh: list[str] = []   # блоки для stdout (только новое)
    all_lessons: dict[str, list[str]] = {}  # полный отчёт (все файлы)
    stat = {"files": 0, "hits": 0}

    for label, path in collect_files():
        p = Path(path)
        mt = mtime_key(p)
        fresh_state[path] = mt
        lessons = extract_lessons(path)
        if not lessons:
            continue
        stat["files"] += 1
        stat["hits"] += len(lessons)
        all_lessons[label] = lessons
        if args.full or state.get(path, 0) < mt:
            fresh.append(f"## {label}\n" + "\n".join(lessons) + "\n")

    # полный отчёт — всегда в файл
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        f"# Уроки сессий ru-мода — {now}",
        "",
        f"Источники: Obsidian sessions/ (ru-mod*), UPSTREAM-WATCH.md, CHANGELOG.md,",
        "ru-mod-backlog.md, ru-mod-promo-plan.md.",
        "",
        f"Файлов с маркерами: {stat['files']}; пересканов-строк: {stat['hits']}.",
        "",
    ]
    for label in sorted(all_lessons):
        lines.append(f"## {label}")
        lines.extend(all_lessons[label])
        lines.append("")
    REPORT.write_text("\n".join(lines), encoding="utf-8")

    STATE.write_text(json.dumps(fresh_state, indent=2), encoding="utf-8")

    if args.full:
        print(f"session-lessons: {stat['files']} файлов с маркерами, отчёт: {REPORT}")
        for block in fresh:
            print(block)
        if not fresh:
            print("(маркеров не найдено)")
        return 0

    if not fresh:
        return 0  # тишина для no_agent-крона
    print(f"session-lessons: новое ({len(fresh)} файлов), полный отчёт: {REPORT}")
    for block in fresh:
        print(block)
    return 0


if __name__ == "__main__":
    sys.exit(main())