#!/usr/bin/env python3
"""GEN v2: build overrides rules from the ACTUAL lines in plugin.js.
Map: visible english scalar value -> russian. We look up each target by
its (prop, value) and take the real line (with indentation) as 'before'.
This survives indent drift and eol. Prints any value not found."""
import re, json

path = '/tmp/fresh-src/apps/desktop/src/plugins/hermes-bots/plugin.js'
lines = open(path, encoding='utf-8').read().split('\n')

# Translation map: value -> russian value (unicode-aware, incl \u escapes kept literal)
T = {
 'Bots': 'Боты',
 'Back': 'Назад',
 'Cancel': 'Отмена',
 'Delete': 'Удалить',
 'Duplicate': 'Дублировать',
 'Reply': 'Ответить',
 'Reply in thread': 'Ответить в ветке',
 'Retry': 'Повторить',
 'Retry now': 'Повторить сейчас',
 'Save': 'Сохранить',
 'Save & test': 'Сохранить и проверить',
 'Upload': 'Загрузить',
 'Active now': 'Активен сейчас',
 'Edit Profile': 'Изменить профиль',
 'New Agent': 'Новый агент',
 'New chat with this agent': 'Новый чат с этим агентом',
 'New Thread': 'Новая ветка',
 'New Group Chat': 'Новый групповой чат',
 'New Cronjob': 'Новая задача по расписанию',
 'Cronjobs': 'Задачи по расписанию',
 'Activity': 'Активность',
 'Auto': 'Авто',
 'Classic shapes': 'Классические формы',
 'Create & join': 'Создать и вступить',
 'Group settings': 'Настройки группы',
 'Inherit (launch profile)': 'Наследовать (профиль запуска)',
 'Manage groups': 'Управлять группами',
 'Skills Hub': 'Хаб навыков',
 'Hermes Skills Hub': 'Хаб навыков Hermes',
 'Remove': 'Убрать',
 'Remove from all groups': 'Убрать из всех групп',
 'Remove image — use shape': 'Убрать изображение — использовать форму',
 'Remove — back to shape avatar': 'Убрать — вернуть аватар-форму',
 'Remove attachment': 'Убрать вложение',
 'Remove from selection': 'Убрать из выделения',
 'Pinned': 'Закреплено',
 'This chat never resets': 'Этот чат никогда не сбрасывается',
 'Open this thread': 'Открыть ветку',
 'Collapse this thread': 'Свернуть ветку',
 'No agents yet': 'Пока нет агентов',
 'Hidden from the roster': 'Скрыт из списка',
 'Attach files — every responding bot sees them': 'Прикрепить файлы — их увидят все отвечающие боты',
 'A bot in this room needs your input': 'Бот в этой комнате ждёт вашего ответа',
 'No MCP servers configured or in the catalog.': 'Серверы MCP не настроены и отсутствуют в каталоге.',
 'No activity in this turn yet.': 'В этом ходе пока нет активности.',
 'No hub skills matched.': 'Ничего не найдено в хабе навыков.',
 'No pets match.': 'Питомцы не найдены.',
 'No pets in the petdex gallery. Run `hermes pets` to explore.': 'В галерее petdex нет питомцев. Выполните `hermes pets`, чтобы изучить их.',
 'needs you': 'ждёт вас',
 '✓ added': '✓ добавлено',
 'Could not load cronjobs. The list may still be there.': 'Не удалось загрузить задачи по расписанию. Возможно, список всё ещё существует.',
 'A named teammate with its own memory, skills, and chat. It can message your other agents.': 'Именованный напарник со своей памятью, навыками и чатом. Может писать вашим другим агентам.',
 'A bot can join multiple group chats. Memberships sync to every machine.': 'Бот может состоять в нескольких групповых чатах. Членства синхронизируются на всех машинах.',
 'Say something — every bot in this group hears the room.': 'Напишите что-нибудь — каждый бот в этой группе услышит комнату.',
 'Paused for security: delete and recreate this legacy cronjob before running it again.': 'Приостановлено в целях безопасности: удалите и заново создайте эту старую задачу, чтобы запустить её снова.',
 'Pick a pet as this agent’s profile picture.': 'Выберите питомца как аватар этого агента.',
 'Rename the group or set a room picture. Members and history are kept.': 'Переименуйте группу или установите изображение комнаты. Участники и история сохраняются.',
 'Full configuration needs a newer gateway (restart it after updating Hermes).': 'Для полной настройки нужен более новый шлюз (перезапустите его после обновления Hermes).',
 'Fresh profile (bundled skills)': 'Чистый профиль (встроенные навыки)',
 '“Create empty” is checked — no bundled skills will be installed.': 'Отмечено «Создать пустым» — встроенные навыки не будут установлены.',
 'Leave blank to generate from the agent\\u2019s name and description.': 'Оставьте пустым, чтобы сгенерировать из имени и описания агента.',
 'Leaving all (or none) checked keeps the default toolset behavior.': 'Если отмечены все (или ни один) — останется стандартное поведение набора инструментов.',
 'Bot Mode — a one-chat-per-agent roster with avatars, routines, group chats, and bot-to-bot messaging. Ships with the app; disable here if unwanted.': 'Режим ботов — список с чатом на каждого агента: аватары, расписания, групповые чаты и обмен сообщениями между ботами. Входит в приложение; отключите здесь, если не нужен.',
 'Create your first teammate.': 'Создайте своего первого напарника.',
 'Disband group chat?': 'Расформировать групповой чат?',
 'Delete bot and profile?': 'Удалить бота и профиль?',
 'Delete cronjob': 'Удалить задачу по расписанию',
 'minutes': 'минут',
 'minutes from now': 'минут от текущего',
 'hours': 'часов',
 'hours from now': 'часов от текущего',
 'days': 'дней',
 'days from now': 'дней от текущего',
 'Once, in…': 'Один раз, через…',
 'Every hour': 'Каждый час',
 'Every day': 'Каждый день',
 'Every week': 'Каждую неделю',
 'Every month': 'Каждый месяц',
 'Interval': 'Интервал',
 'Weekdays': 'По будням',
 'Monday': 'Понедельник',
 'Tuesday': 'Вторник',
 'Wednesday': 'Среда',
 'Thursday': 'Четверг',
 'Friday': 'Пятница',
 'Saturday': 'Суббота',
 'Sunday': 'Воскресенье',
 'New Agent…': 'Новый агент…',
 'New…': 'Новый…',
 'Advanced…': 'Дополнительно…',
 '← Back to dropdowns': '← Назад к спискам',
 '✏️ Enter manually…': '✏️ Ввести вручную…',
 'Working\\u2026': 'Работаю…',
 'set up \\u2713': 'настроено ✓',
 'retry': 'повторить',
 'Stop after': 'Остановить после',
 'runs (blank = forever)': 'выполнений (пусто = бессрочно)',
 'needs setup (': 'требует настройки (',
 'What should this agent help with?': 'С чем должен помогать этот агент?',
 'What should this Bot help with?': 'С чем должен помогать этот бот?',
 'What should this cronjob do each time it runs?': 'Что должна делать эта задача при каждом запуске?',
 'Search bots…': 'Поиск ботов…',
 'Search bots to add…': 'Поиск ботов для добавления…',
 'Name this cronjob': 'Название задачи по расписанию',
 'Describe your avatar…': 'Опишите аватар…',
 'Inbox Triage': 'Разбор входящих',
 'Filter skills…': 'Фильтр навыков…',
 'Search the hub (community + well-known sources)…': 'Поиск в хабе (сообщество и известные источники)…',
 'Bot Chat': 'Чат бота',
}

# pattern to find lines:  prop: 'literal'  or  prop: "literal"
PROPS = re.compile(r"^(?P<ind>\s*)(?P<prop>children|label|title|placeholder|alt|description)\s*:\s*'(?P<val>(?:[^'\\]|\\.)*)'\s*,?\s*(?://.*)?$")

# find value->lines
from collections import defaultdict
val_lines = defaultdict(list)
for i, ln in enumerate(lines):
    m = PROPS.match(ln)
    if m:
        # decode: keep literal escape text as in file
        val_lines[m.group('val')].append((i, ln))

rules = []
seen_vals = set()
notfound = []
for val, ru in T.items():
    key = val.replace('\\\\', '\\\\')  # literal as in T
    # python's T used '\\u' -> actual backslash-u in the key; file has same? plugin.js writes '\u' as backslash+u? In source the file literally contains backslash-u sequences (escaped in the .js). Our PROPS captured raw. compare raw.
    occ = val_lines.get(val, [])
    if not occ:
        notfound.append(val)
        continue
    # build rule for each unique line; if multiple identical lines, use all:true if identical
    seen_vals.add(val)
    mapped = f"{occ[0][1][:occ[0][1].index(val)]}{ru}{occ[0][1][occ[0][1].index(val)+len(val):]}"
    rule = {
        "id": f"hermes-bots-{val[:24].replace(' ','_')}",
        "file": "apps/desktop/src/plugins/hermes-bots/plugin.js",
        "before": [occ[0][1]],
        "after": [mapped.rstrip()],
    }
    # count identical lines -> if >1, all:true
    same = [ln for (j, ln) in val_lines[val] if ln == occ[0][1]]
    if len(same) > 1:
        rule["all"] = True
    rules.append(rule)

print(f"rules: {len(rules)} ; not found: {len(notfound)}")
for v in notfound:
    print("  NOTFOUND:", v[:80])
with open('/tmp/bots-overrides.json', 'w', encoding='utf-8') as f:
    json.dump(rules, f, ensure_ascii=False, indent=1)
print("wrote /tmp/bots-overrides.json")
