#!/bin/bash
# ============================================================================
# Сборщик системных метрик для Hermes cron (deep health check)
# Запускается каждый час, вывод передаётся агенту для анализа
# v2: конденсированный вывод + детект HF incomplete downloads
# Для отладки: VERBOSE=1 ./collect-metrics.sh
# ============================================================================

echo "=== СИСТЕМНЫЙ ОТЧЁТ $(date '+%Y-%m-%d %H:%M:%S %Z') ==="
echo ""

echo "── ПАМЯТЬ ──"
# Конденсированный вывод: парсим free в байтах (без -h) для точного %
free | awk '
  NR==2 {ram_used=$3; ram_total=$2; ram_avail=$7; ram_cache=$6}
  NR==3 {swap_used=$3; swap_total=$2}
  END {
    printf "RAM: %.0fM/%.0fM | avail: %.0fM | cache: %.0fM\n", ram_used/1024, ram_total/1024, ram_avail/1024, ram_cache/1024
    if (swap_total > 0)
      printf "Swap: %.0fM/%.0fM (%d%%)\n", swap_used/1024, swap_total/1024, swap_used*100/swap_total
    else
      print "Swap: нет"
  }'
echo ""

echo "── ДИСК ──"
df -h / | awk 'NR==2 {printf "Disk: %s/%s (%s used)\n", $3, $2, $5}'
echo ""

echo "── ПРОЦЕСС HERMES ──"
HERMES_PROCS=$(pgrep -f "hermes" -c 2>/dev/null || echo 0)
echo "Процессов Hermes: $HERMES_PROCS"
# Воркеры канбана/агентов (hermes -p <profile> ...). В норме 0; шторм = 3+.
HERMES_WORKERS=$(pgrep -f "hermes.* -p " -c 2>/dev/null || echo 0)
echo "Воркеров (kanban/агенты): $HERMES_WORKERS"
if [ "$VERBOSE" = "1" ]; then
    pgrep -f "hermes" -a | head -5
fi
echo ""

echo "── СЕРВИСЫ ──"
DASH=$(systemctl --user is-active hermes-dashboard 2>/dev/null || echo "inactive")
GW=$(systemctl --user is-active hermes-gateway 2>/dev/null || echo "inactive")
echo "hermes-dashboard: $DASH  hermes-gateway: $GW"
echo ""

echo "── НАГРУЗКА ──"
uptime | awk -F'load average:' '{print "Load:" $2}'
echo ""

echo "── ОШИБКИ GATEWAY (400 строк) ──"
grep -i "error\|traceback\|fail\|exception" /home/ubuntu/.hermes/logs/gateway.log 2>/dev/null | tail -20 || echo "Лог gateway не найден"
echo ""

echo "── OOM KILLER ──"
dmesg 2>/dev/null | grep -i "oom\|killed process" | tail -5 || echo "Нет"
echo ""

echo "── FAIL2BAN ──"
sudo fail2ban-client status sshd 2>/dev/null | grep -E "Currently failed|Total failed" || echo "Нет данных"
echo ""

echo "── ПОРТЫ ──"
ss -tlnp 2>/dev/null | grep -E "22|9119" | awk '{print $4, $NF}' | head -10
echo ""

echo "── HF CACHE (модели HuggingFace) ──"
if [ -d ~/.cache/huggingface/ ]; then
    du -sh ~/.cache/huggingface/ 2>/dev/null
    INCOMPLETE=$(find ~/.cache/huggingface/ -name "*.incomplete" 2>/dev/null)
    if [ -n "$INCOMPLETE" ]; then
        echo "⚠️ INCOMPLETE DOWNLOADS:"
        echo "$INCOMPLETE" | while read f; do
            echo "  $(ls -lh "$f" | awk '{print $5, $NF}')"
        done
    fi
else
    echo "HF cache: нет"
fi
echo ""

echo "── СЕТЬ (network-guard) ──"
cat ~/.hermes/state/network-guard/state.json 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print('Network guard: last=%s dns_ok=%s rules_ok=%s e2e=%s fails=%s' % (d.get('last_check','?'), d.get('dns_ok','?'), d.get('rules_ok','?'), d.get('e2e','?'), d.get('fails',0)))" 2>/dev/null || echo "Network guard: state отсутствует"
echo ""

echo "── WATCHDOG ──"
tail -3 /home/ubuntu/.hermes/logs/watchdog.log 2>/dev/null || echo "Нет данных"

# VERBOSE mode — полный вывод для отладки
if [ "$VERBOSE" = "1" ]; then
    echo ""
    echo "=== VERBOSE MODE ==="
    echo ""
    echo "── ПОЛНЫЙ ВЫВОД ПАМЯТИ ──"
    free -h
    echo ""
    echo "── ПОЛНЫЙ ВЫВОД ПРОЦЕССОВ ──"
    pgrep -f "hermes" -a | head -5 || echo "Нет"
    echo ""
    echo "── ПОЛНЫЙ FAIL2BAN ──"
    sudo fail2ban-client status sshd 2>/dev/null | head -10
fi
