#!/usr/bin/env python3
"""session-leak-check.py — watchdog for leaked active-session leases.

Hermes bug #57052: desktop/TUI tabs pin max_concurrent_sessions slots
(claimed at composer paint, never released while connected). Leases in
active_sessions.json accumulate and eventually block new sessions.

This script (no_agent cron, hourly):
  1. Reads ~/.hermes/runtime/active_sessions.json
  2. Classifies each lease as alive or dead:
       cron_*   -> dead if no live worker AND session older than 2h
       desktop  -> dead if last DB message older than 24h
  3. Removes dead leases (with backup) -> frees slots
  4. Kills orphan cron workers (lease gone, worker alive >1h)
  5. Alerts (non-empty stdout) if leases still >= max_concurrent_sessions

Safety rules (why this won't kill your active session):
  - The CURRENT session always has fresh messages in state.db -> never
    older than 24h -> never classified dead.
  - Cron jobs are short (minutes); their workers exit on completion. A
    lease with no live worker for 2h is a finished job.
  - Backups: active_sessions.json.bak kept before every rewrite.

Manual fallback commands (for the agent, when alert fires):
  hermes sessions list | grep <session_id>
  hermes sessions delete <session_id>   # remove from DB
  pkill -f "slash_worker.*<session_key>"
"""

import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

HOME = Path.home()
LEASES = HOME / ".hermes" / "runtime" / "active_sessions.json"
STATE_DB = HOME / ".hermes" / "state.db"
CONFIG = HOME / ".hermes" / "config.yaml"

CRON_STALE_H = 2      # cron lease without live worker for 2h = finished
DESKTOP_STALE_H = 24  # desktop lease with no DB activity for 24h = dead
ORPHAN_WORKER_H = 1   # worker alive >1h after its lease was removed = orphan

# max_concurrent_sessions from config.yaml (fallback 10)
MAX_SESSIONS = 10
try:
    import yaml
    cfg = yaml.safe_load(CONFIG.read_text()) or {}
    MAX_SESSIONS = int(cfg.get("max_concurrent_sessions", 10))
except Exception:
    pass


def now() -> float:
    return time.time()


def live_workers() -> dict:
    """session_key -> pid for every live slash_worker process."""
    out = subprocess.run(
        ["pgrep", "-af", "slash_worker"], capture_output=True, text=True
    ).stdout
    workers = {}
    for line in out.splitlines():
        m = re.search(r"--session-key\s+(\S+)", line)
        pid_m = re.match(r"(\d+)", line)
        if m and pid_m:
            workers[m.group(1)] = int(pid_m.group(1))
    return workers


def last_message_age(session_id: str) -> float | None:
    """Age in hours of the newest message for session_id, or None."""
    try:
        conn = sqlite3.connect(f"file:{STATE_DB}?mode=ro", uri=True, timeout=10)
        row = conn.execute(
            "SELECT MAX(timestamp) FROM messages WHERE session_id = ?",
            (session_id,),
        ).fetchone()
        conn.close()
        if not row or row[0] is None:
            return None
        return (now() - row[0]) / 3600
    except Exception:
        return None


def classify(lease, workers) -> tuple[str, str]:
    """Return (alive|dead, reason)."""
    sid = lease.get("session_id", "")
    is_cron = sid.startswith("cron_")
    worker_exists = sid in workers

    if is_cron:
        # Extract job timestamp from key: cron_<jobid>_<YYYYMMDD_HHMMSS>
        m = re.search(r"_(\d{8}_\d{6})$", sid)
        if not m:
            return "alive", "cron-lease with unparseable key"
        age_h = (now() - time.mktime(time.strptime(m.group(1), "%Y%m%d_%H%M%S"))) / 3600
        if worker_exists:
            return "alive", f"cron worker running ({age_h:.1f}h)"
        if age_h > CRON_STALE_H:
            return "dead", f"cron finished {age_h:.1f}h ago, no worker"
        return "alive", f"cron recent ({age_h:.1f}h)"

    # desktop / other
    if worker_exists:
        return "alive", "worker running"
    msg_age = last_message_age(sid)
    if msg_age is None:
        return "dead", "no DB messages at all"
    if msg_age > DESKTOP_STALE_H:
        return "dead", f"no activity {msg_age:.1f}h"
    return "alive", f"recent activity {msg_age:.1f}h ago"


def main():
    if not LEASES.exists():
        print("session-leak-check: no active_sessions.json, nothing to do")
        return 0

    leases = json.loads(LEASES.read_text())
    entries = leases.get("entries", [])
    if not entries:
        return 0

    workers = live_workers()
    dead_ids = []
    reasons = []
    for lease in entries:
        status, reason = classify(lease, workers)
        if status == "dead":
            dead_ids.append(lease["session_id"])
            reasons.append(f"  {lease['session_id'][:44]:46s} {reason}")

    # Kill orphan workers (their lease is gone but process alive)
    orphan_pids = []
    lease_keys = {e.get("session_id") for e in entries}
    for key, pid in workers.items():
        if key not in lease_keys:
            age_h = (now() - _proc_start(pid)) / 3600 if _proc_start(pid) else 0
            if age_h > ORPHAN_WORKER_H:
                orphan_pids.append(pid)

    # Remove dead leases (with backup)
    if dead_ids:
        shutil.copy2(LEASES, LEASES.with_suffix(".json.bak"))
        kept = [e for e in entries if e["session_id"] not in dead_ids]
        leases["entries"] = kept
        LEASES.write_text(json.dumps(leases, indent=2))

    for pid in orphan_pids:
        subprocess.run(["kill", str(pid)], capture_output=True)

    remaining = len(leases["entries"])

    # Alert only if we still hit the cap (auto-clean wasn't enough)
    lines = []
    if dead_ids:
        lines.append(f"session-leak-check: removed {len(dead_ids)} dead leases")
        lines += reasons
    if orphan_pids:
        lines.append(f"session-leak-check: killed {len(orphan_pids)} orphan workers (pids: {', '.join(map(str, orphan_pids))})")
    if remaining >= MAX_SESSIONS:
        lines.append("")
        lines.append(f"⚠️  STILL AT CAP: {remaining}/{MAX_SESSIONS} leases after cleanup")
        lines.append("Manual cleanup — pick dead ones from: hermes sessions list")
        lines.append("  hermes sessions delete <session_id>")
        lines.append("  pkill -f 'slash_worker.*<session_key>'")
        lines.append("Current leases:")
        for e in leases["entries"]:
            lines.append(f"  {e['session_id'][:44]:46s} surface={e.get('surface','?')}")

    if lines:
        print("\n".join(lines))
        return 1
    return 0


def _proc_start(pid: int) -> float | None:
    try:
        out = subprocess.run(
            ["ps", "-o", "lstart=", "-p", str(pid)], capture_output=True, text=True
        ).stdout.strip()
        return time.mktime(time.strptime(out, "%a %b %d %H:%M:%S %Y")) if out else None
    except Exception:
        return None


if __name__ == "__main__":
    sys.exit(main())
