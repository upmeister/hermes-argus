"""telegram_path — shared Telegram proxy resolver.

Reads ``~/.hermes/state/telegram-path-state.json`` (managed by
``telegram-path-manager.sh`` cron job) and returns the appropriate proxy URL
for any program that calls the Telegram API.

Priority:
  1. If telegram-smart-proxy is running (port 8444) → always use it.
     It handles direct/Tor/VLESS routing internally, zero restarts.
  2. Fall back to path-manager state:
     - mode=tor → socks5://127.0.0.1:9050
     - mode=direct → None (no proxy)
     - mode=blocked / unknown → None (caller should try socks5)

Usage::

    from telegram_path import get_proxy

    proxy = get_proxy()
    if proxy:
        # Pass to your HTTP library:
        #   httpx:     builder.proxy(proxy)
        #   urllib:    os.environ["HTTPS_PROXY"] = proxy
    # proxy=None means direct connection
"""

from __future__ import annotations

import json
import os
import socket

__all__ = ["get_proxy"]


def _get_state_path() -> str:
    home = os.path.expanduser("~")
    return f"{home}/.hermes/state/telegram-path-state.json"


def _smart_proxy_available() -> bool:
    """Check if telegram-smart-proxy is listening on 127.0.0.1:8444."""
    try:
        with socket.create_connection(("127.0.0.1", 8444), timeout=0.5):
            return True
    except (OSError, socket.error):
        return False


def _read_mode() -> str | None:
    """Read current proxy mode from state file."""
    state_path = _get_state_path()
    try:
        with open(state_path) as f:
            data = json.load(f)
        return data.get("mode")
    except (FileNotFoundError, json.JSONDecodeError, KeyError):
        return None


def get_proxy() -> str | None:
    """Return the best Telegram proxy URL, or None for direct connection."""
    # Smart proxy (8444) always wins — it handles direct → Tor → VLESS internally
    if _smart_proxy_available():
        return "http://127.0.0.1:8444"
    # Fall back to path-manager state
    mode = _read_mode()
    if mode == "tor":
        return "socks5://127.0.0.1:9050"
    # direct, blocked, unknown → no proxy (caller should try socks5 on error)
    return None